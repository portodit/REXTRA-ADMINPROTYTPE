
CREATE TABLE public.membership_transactions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  transaction_id text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  primary_status text NOT NULL DEFAULT 'BERLANGSUNG',
  change_type text NOT NULL DEFAULT 'PEMBELIAN_BARU',
  
  -- User
  user_id text NOT NULL,
  user_name text NOT NULL,
  user_email text NOT NULL,
  
  -- Plan change
  from_plan text,
  to_plan text NOT NULL DEFAULT 'BASIC',
  from_duration_months integer,
  to_duration_months integer,
  
  -- Amount
  subtotal integer NOT NULL DEFAULT 0,
  discount integer NOT NULL DEFAULT 0,
  promo_code text,
  total integer NOT NULL DEFAULT 0,
  
  -- Payment
  payment_provider text DEFAULT 'XENDIT',
  payment_method text,
  xendit_invoice_id text,
  payment_url text,
  payment_status_raw text,
  payment_status_display text,
  paid_at timestamptz,
  expires_at timestamptz,
  
  -- Cancellation
  cancel_reason text,
  canceled_at timestamptz,
  cancel_note text,
  
  -- Invoice document
  invoice_document_url text,
  
  -- Items (JSON array)
  items jsonb DEFAULT '[]'::jsonb
);

-- RLS
ALTER TABLE public.membership_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "membership_transactions_all" ON public.membership_transactions
  AS PERMISSIVE FOR ALL USING (true) WITH CHECK (true);
