
-- Rename restriction_type 'limit' to 'frequency_limited' in entitlements
UPDATE public.entitlements SET restriction_type = 'frequency_limited' WHERE restriction_type = 'limit';

-- Clear usage_limit in entitlements (no longer used at entitlement level)
UPDATE public.entitlements SET usage_limit = 0;

-- Rename restriction_type 'limit' to 'frequency_limited' in duration_access_mappings
UPDATE public.duration_access_mappings SET restriction_type = 'frequency_limited' WHERE restriction_type = 'limit';
