
-- Membership Plans
CREATE TABLE public.membership_plans (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'unpaid',
  status TEXT NOT NULL DEFAULT 'draft',
  emblem_key TEXT NOT NULL DEFAULT 'starter',
  description TEXT,
  tier_label TEXT,
  active_users INTEGER DEFAULT 0,
  duration_mode TEXT DEFAULT 'tanpa_durasi',
  pricing_mode TEXT DEFAULT 'manual',
  base_price_1m INTEGER DEFAULT 0,
  base_token_1m INTEGER DEFAULT 0,
  discount_3m NUMERIC(5,2) DEFAULT 0,
  discount_6m NUMERIC(5,2) DEFAULT 0,
  discount_12m NUMERIC(5,2) DEFAULT 0,
  bonus_token_3m INTEGER DEFAULT 0,
  bonus_token_6m INTEGER DEFAULT 0,
  bonus_token_12m INTEGER DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT now(),
  updated_by TEXT DEFAULT 'System',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Plan Durations (1/3/6/12 months per plan)
CREATE TABLE public.plan_durations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id TEXT NOT NULL REFERENCES public.membership_plans(id) ON DELETE CASCADE,
  duration_months INTEGER NOT NULL,
  is_active BOOLEAN DEFAULT false,
  price INTEGER DEFAULT 0,
  discount_percent NUMERIC(5,2) DEFAULT 0,
  final_price INTEGER DEFAULT 0,
  token_amount INTEGER DEFAULT 0,
  bonus_token INTEGER DEFAULT 0,
  points_active BOOLEAN DEFAULT false,
  points_value INTEGER DEFAULT 0,
  bonus_points INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(plan_id, duration_months)
);

-- Access Mappings per Duration
CREATE TABLE public.duration_access_mappings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_duration_id UUID NOT NULL REFERENCES public.plan_durations(id) ON DELETE CASCADE,
  entitlement_name TEXT NOT NULL,
  entitlement_key TEXT NOT NULL,
  category TEXT,
  restriction_type TEXT NOT NULL DEFAULT 'unlimited',
  token_cost INTEGER DEFAULT 0,
  usage_limit INTEGER DEFAULT 0,
  reset_period TEXT,
  status TEXT NOT NULL DEFAULT 'aktif',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.membership_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plan_durations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.duration_access_mappings ENABLE ROW LEVEL SECURITY;

-- Public read/write policies (admin dashboard, no auth required for V1)
CREATE POLICY "membership_plans_all" ON public.membership_plans FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "plan_durations_all" ON public.plan_durations FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "duration_access_mappings_all" ON public.duration_access_mappings FOR ALL USING (true) WITH CHECK (true);

-- Seed membership plans
INSERT INTO public.membership_plans (id, name, category, status, emblem_key, description, tier_label, active_users, duration_mode, pricing_mode, base_price_1m, base_token_1m) VALUES
  ('standard', 'Standard', 'unpaid', 'aktif', 'starter', 'Akses standar gratis untuk semua pengguna REXTRA.', 'NON CLUB', 1200, 'tanpa_durasi', 'manual', 0, 5),
  ('starter', 'Starter', 'unpaid', 'aktif', 'starter', 'Akses dasar untuk pengguna baru yang ingin mencoba fitur REXTRA.', 'TRIAL CLUB', 340, 'tanpa_durasi', 'manual', 0, 10),
  ('basic', 'Basic', 'paid', 'aktif', 'basic', 'Paket entry-level untuk mahasiswa tahun 1-2.', 'REXTRA CLUB', 87, 'dengan_durasi', 'manual', 180000, 10),
  ('pro', 'Pro', 'paid', 'draft', 'pro', 'Paket lengkap untuk mahasiswa yang serius mengembangkan karier.', 'REXTRA CLUB', 0, 'dengan_durasi', 'manual', 300000, 20),
  ('max', 'Max', 'paid', 'nonaktif', 'max', 'Paket premium untuk mahasiswa tingkat akhir dan fresh graduate.', 'REXTRA CLUB', 12, 'dengan_durasi', 'manual', 500000, 30);

-- Seed durations for each plan
INSERT INTO public.plan_durations (plan_id, duration_months, is_active, price, token_amount, points_active, points_value)
SELECT p.id, d.m,
  CASE WHEN d.m = 1 THEN true ELSE false END,
  CASE WHEN p.category = 'paid' AND d.m = 1 THEN
    CASE p.id WHEN 'basic' THEN 180000 WHEN 'pro' THEN 300000 WHEN 'max' THEN 500000 ELSE 0 END
  ELSE 0 END,
  CASE WHEN d.m = 1 THEN
    CASE p.id WHEN 'standard' THEN 5 WHEN 'starter' THEN 10 WHEN 'basic' THEN 10 WHEN 'pro' THEN 20 WHEN 'max' THEN 30 ELSE 0 END
  ELSE 0 END,
  CASE WHEN p.category = 'paid' AND d.m = 1 THEN true ELSE false END,
  CASE WHEN p.category = 'paid' AND d.m = 1 THEN
    CASE p.id WHEN 'basic' THEN 100 WHEN 'pro' THEN 200 WHEN 'max' THEN 400 ELSE 0 END
  ELSE 0 END
FROM public.membership_plans p
CROSS JOIN (VALUES (1), (3), (6), (12)) AS d(m);

-- Enable realtime for plans
ALTER PUBLICATION supabase_realtime ADD TABLE public.membership_plans;
