ALTER TABLE public.invoice_settings 
  ADD COLUMN IF NOT EXISTS company_address text DEFAULT '',
  ADD COLUMN IF NOT EXISTS invoice_title text DEFAULT 'FAKTUR',
  ADD COLUMN IF NOT EXISTS email_footer_text text DEFAULT '© 2026 Rextra Technology · Email dikirim otomatis';