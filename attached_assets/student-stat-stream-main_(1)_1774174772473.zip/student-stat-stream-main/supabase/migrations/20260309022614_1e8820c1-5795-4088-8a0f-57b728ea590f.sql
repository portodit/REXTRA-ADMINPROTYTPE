
-- 1. ENTITLEMENTS: Update restriction_type values and remove usage_limit
-- Update existing 'token' values to 'token_gated'
UPDATE public.entitlements SET restriction_type = 'token_gated' WHERE restriction_type = 'token';

-- Drop usage_limit column (not needed per brief - usage quota goes to mapping)
ALTER TABLE public.entitlements DROP COLUMN IF EXISTS usage_limit;

-- 2. DURATION_ACCESS_MAPPINGS: Rename usage_limit to usage_quota, remove restriction_type/token_cost/reset_period
-- Add usage_quota column
ALTER TABLE public.duration_access_mappings ADD COLUMN IF NOT EXISTS usage_quota integer NOT NULL DEFAULT 0;
-- Copy data from usage_limit to usage_quota
UPDATE public.duration_access_mappings SET usage_quota = COALESCE(usage_limit, 0);
-- Drop old columns that should not be in mapping per brief
ALTER TABLE public.duration_access_mappings DROP COLUMN IF EXISTS usage_limit;
ALTER TABLE public.duration_access_mappings DROP COLUMN IF EXISTS restriction_type;
ALTER TABLE public.duration_access_mappings DROP COLUMN IF EXISTS token_cost;
ALTER TABLE public.duration_access_mappings DROP COLUMN IF EXISTS reset_period;

-- Make entitlement_id NOT NULL (first set any nulls)
UPDATE public.duration_access_mappings SET entitlement_id = gen_random_uuid() WHERE entitlement_id IS NULL;
ALTER TABLE public.duration_access_mappings ALTER COLUMN entitlement_id SET NOT NULL;

-- 3. MEMBERSHIP_PLANS: Add benefits column
ALTER TABLE public.membership_plans ADD COLUMN IF NOT EXISTS benefits jsonb DEFAULT '[]'::jsonb;

-- 4. USER_MEMBERSHIPS: Add missing columns per Memberships entity brief
ALTER TABLE public.user_memberships ADD COLUMN IF NOT EXISTS plan_id text;
ALTER TABLE public.user_memberships ADD COLUMN IF NOT EXISTS duration_id uuid;
ALTER TABLE public.user_memberships ADD COLUMN IF NOT EXISTS plan_name text;
ALTER TABLE public.user_memberships ADD COLUMN IF NOT EXISTS duration_months integer DEFAULT 0;
ALTER TABLE public.user_memberships ADD COLUMN IF NOT EXISTS auto_renew boolean NOT NULL DEFAULT false;
ALTER TABLE public.user_memberships ADD COLUMN IF NOT EXISTS current_token_balance integer NOT NULL DEFAULT 0;
ALTER TABLE public.user_memberships ADD COLUMN IF NOT EXISTS current_poin_balance integer NOT NULL DEFAULT 0;
ALTER TABLE public.user_memberships ADD COLUMN IF NOT EXISTS started_at timestamptz;
ALTER TABLE public.user_memberships ADD COLUMN IF NOT EXISTS expired_at timestamptz;

-- 5. SUBSCRIPTION_CYCLES: Add plan_duration_id and membership_id
ALTER TABLE public.subscription_cycles ADD COLUMN IF NOT EXISTS plan_duration_id uuid;
ALTER TABLE public.subscription_cycles ADD COLUMN IF NOT EXISTS membership_id uuid;
-- Copy user_membership_id to membership_id for existing data
UPDATE public.subscription_cycles SET membership_id = user_membership_id WHERE membership_id IS NULL;

-- 6. CREATE PAYMENT_TRANSACTIONS TABLE (new per brief)
CREATE TABLE IF NOT EXISTS public.payment_transactions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  transaction_id text NOT NULL UNIQUE,
  user_id uuid NOT NULL,
  membership_id uuid,
  change_type text NOT NULL DEFAULT 'PEMBELIAN_BARU',
  from_plan text,
  to_plan text NOT NULL DEFAULT 'Basic',
  from_duration_months integer,
  to_duration_months integer NOT NULL DEFAULT 1,
  plan_id uuid,
  duration_id uuid,
  subtotal_amount bigint NOT NULL DEFAULT 0,
  discount_amount bigint NOT NULL DEFAULT 0,
  duration_credit bigint NOT NULL DEFAULT 0,
  total_amount bigint NOT NULL DEFAULT 0,
  promo_code text,
  payment_provider text DEFAULT 'TRIPAY',
  payment_method text,
  payment_status text NOT NULL DEFAULT 'PENDING',
  payment_external_id text,
  merchant_ref text,
  payment_url text,
  pay_code text,
  user_name text,
  user_email text,
  items jsonb DEFAULT '[]'::jsonb,
  primary_status text DEFAULT 'BERLANGSUNG',
  paid_at timestamptz,
  expires_at timestamptz,
  canceled_at timestamptz,
  cancel_reason text,
  cancel_note text,
  payment_callback_data jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS on payment_transactions
ALTER TABLE public.payment_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "payment_transactions_all" ON public.payment_transactions FOR ALL USING (true) WITH CHECK (true);

-- 7. CREATE POIN_TRANSACTIONS TABLE (missing per brief)
CREATE TABLE IF NOT EXISTS public.poin_transactions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_membership_id uuid NOT NULL,
  amount integer NOT NULL DEFAULT 0,
  mutation_type text NOT NULL DEFAULT 'earn',
  source text NOT NULL DEFAULT 'membership',
  description text,
  reference_id text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.poin_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "poin_transactions_all" ON public.poin_transactions FOR ALL USING (true) WITH CHECK (true);

-- 8. CREATE TOKEN_USAGE_HISTORY TABLE (missing per brief)
CREATE TABLE IF NOT EXISTS public.token_usage_history (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_membership_id uuid NOT NULL,
  entitlement_key text NOT NULL,
  entitlement_name text NOT NULL,
  token_cost integer NOT NULL DEFAULT 0,
  result text NOT NULL DEFAULT 'success',
  error_message text,
  reference_id text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.token_usage_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "token_usage_history_all" ON public.token_usage_history FOR ALL USING (true) WITH CHECK (true);

-- 9. CREATE REDEMPTION_CODES TABLE (missing per brief - tracks discount code usage counts)
ALTER TABLE public.discounts ADD COLUMN IF NOT EXISTS current_redemptions integer NOT NULL DEFAULT 0;
