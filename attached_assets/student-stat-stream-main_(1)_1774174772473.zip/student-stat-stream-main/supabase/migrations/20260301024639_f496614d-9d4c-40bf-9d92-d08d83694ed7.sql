
-- User memberships (current state per user)
CREATE TABLE public.user_memberships (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id TEXT NOT NULL,
  user_name TEXT NOT NULL,
  user_email TEXT NOT NULL,
  user_type TEXT NOT NULL DEFAULT 'New',
  category TEXT NOT NULL DEFAULT 'Non-Club',
  tier TEXT NOT NULL DEFAULT 'Standard',
  plan_label TEXT,
  start_date TIMESTAMP WITH TIME ZONE,
  end_date TIMESTAMP WITH TIME ZONE,
  is_active BOOLEAN NOT NULL DEFAULT false,
  remaining_days INTEGER NOT NULL DEFAULT 0,
  paid_cycle_count INTEGER NOT NULL DEFAULT 0,
  token_balance INTEGER NOT NULL DEFAULT 0,
  points_balance INTEGER NOT NULL DEFAULT 0,
  entitlement_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Subscription cycles (history per user)
CREATE TABLE public.subscription_cycles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_membership_id UUID NOT NULL REFERENCES public.user_memberships(id) ON DELETE CASCADE,
  cycle_number INTEGER NOT NULL DEFAULT 0,
  plan TEXT NOT NULL,
  category TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  start_date TIMESTAMP WITH TIME ZONE NOT NULL,
  end_date TIMESTAMP WITH TIME ZONE,
  duration_months INTEGER NOT NULL DEFAULT 1,
  amount_paid INTEGER NOT NULL DEFAULT 0,
  transaction_id TEXT,
  payment_channel TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Usage logs
CREATE TABLE public.usage_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_membership_id UUID NOT NULL REFERENCES public.user_memberships(id) ON DELETE CASCADE,
  entitlement_key TEXT NOT NULL,
  entitlement_name TEXT NOT NULL,
  result TEXT NOT NULL DEFAULT 'success',
  error_message TEXT,
  reference_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Token ledger
CREATE TABLE public.token_ledger (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_membership_id UUID NOT NULL REFERENCES public.user_memberships(id) ON DELETE CASCADE,
  mutation_type TEXT NOT NULL DEFAULT 'in',
  amount INTEGER NOT NULL DEFAULT 0,
  source TEXT NOT NULL DEFAULT 'plan_allocation',
  description TEXT,
  reference_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Points ledger
CREATE TABLE public.points_ledger (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_membership_id UUID NOT NULL REFERENCES public.user_memberships(id) ON DELETE CASCADE,
  mutation_type TEXT NOT NULL DEFAULT 'earn',
  amount INTEGER NOT NULL DEFAULT 0,
  source TEXT NOT NULL DEFAULT 'membership',
  description TEXT,
  reference_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- RLS policies (public access for admin dashboard)
ALTER TABLE public.user_memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscription_cycles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.usage_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.token_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.points_ledger ENABLE ROW LEVEL SECURITY;

CREATE POLICY "user_memberships_all" ON public.user_memberships FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "subscription_cycles_all" ON public.subscription_cycles FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "usage_logs_all" ON public.usage_logs FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "token_ledger_all" ON public.token_ledger FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "points_ledger_all" ON public.points_ledger FOR ALL USING (true) WITH CHECK (true);
