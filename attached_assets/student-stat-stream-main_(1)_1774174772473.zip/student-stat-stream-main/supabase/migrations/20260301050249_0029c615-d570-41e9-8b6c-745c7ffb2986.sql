
-- Table 1: Notification settings
CREATE TABLE public.membership_notification_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  is_enabled boolean NOT NULL DEFAULT false,
  triggers text[] NOT NULL DEFAULT '{"D7","D3","D1"}',
  email_subject_template text NOT NULL DEFAULT 'Membership kamu akan berakhir {sisa_hari} hari lagi',
  email_body_template text NOT NULL DEFAULT 'Halo {nama_depan}, membership {nama_plan} kamu akan berakhir pada {tanggal_berakhir} ({sisa_hari} hari lagi). Segera perpanjang agar tetap menikmati semua fitur.',
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by text DEFAULT 'System'
);

ALTER TABLE public.membership_notification_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "membership_notification_settings_all" ON public.membership_notification_settings FOR ALL USING (true) WITH CHECK (true);

-- Table 2: Invoice settings
CREATE TABLE public.invoice_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL DEFAULT 'Rextra',
  footer_text text NOT NULL DEFAULT 'Dokumen ini dibuat secara otomatis oleh sistem.',
  default_due_days integer NOT NULL DEFAULT 0,
  base_invoice_url text DEFAULT '',
  notes text[] DEFAULT '{}',
  invoice_prefix text NOT NULL DEFAULT 'INV',
  invoice_reset_rule text NOT NULL DEFAULT 'MONTHLY',
  logo_url text,
  terms_content text DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by text DEFAULT 'System'
);

ALTER TABLE public.invoice_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "invoice_settings_all" ON public.invoice_settings FOR ALL USING (true) WITH CHECK (true);

-- Table 3: Transaction ID settings
CREATE TABLE public.transaction_id_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trx_prefix text NOT NULL DEFAULT 'TRX',
  trx_pattern text NOT NULL DEFAULT 'DATE_DAILY',
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by text DEFAULT 'System'
);

ALTER TABLE public.transaction_id_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "transaction_id_settings_all" ON public.transaction_id_settings FOR ALL USING (true) WITH CHECK (true);

-- Seed default rows
INSERT INTO public.membership_notification_settings (id) VALUES (gen_random_uuid());
INSERT INTO public.invoice_settings (id) VALUES (gen_random_uuid());
INSERT INTO public.transaction_id_settings (id) VALUES (gen_random_uuid());
