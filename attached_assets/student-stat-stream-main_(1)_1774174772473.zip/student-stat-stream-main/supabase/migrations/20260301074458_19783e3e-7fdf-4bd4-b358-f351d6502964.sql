
CREATE OR REPLACE FUNCTION public.export_all_tables_sql()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
declare
  t record;
  rows_json jsonb;
  output_sql text := '-- Database Export' || E'\n' || '-- Generated: ' || now()::text || E'\n';
begin
  for t in
    select schemaname, tablename
    from pg_tables
    where schemaname = 'public'
      and tablename not like 'pg_%'
      and tablename not like 'sql_%'
    order by tablename
  loop
    begin
      execute format(
        'select coalesce(jsonb_agg(to_jsonb(r)), ''[]''::jsonb) from (select * from %I.%I) r',
        t.schemaname,
        t.tablename
      ) into rows_json;
    exception
      when others then
        continue;
    end;

    output_sql := output_sql || E'\n' || format('-- Table: %I.%I', t.schemaname, t.tablename) || E'\n';

    if jsonb_array_length(rows_json) = 0 then
      output_sql := output_sql || '-- no rows' || E'\n';
    else
      output_sql := output_sql || format(
        'insert into %I.%I select * from jsonb_populate_recordset(null::%I.%I, %L::jsonb);',
        t.schemaname,
        t.tablename,
        t.schemaname,
        t.tablename,
        rows_json::text
      ) || E'\n';
    end if;
  end loop;

  return output_sql;
end;
$function$;
