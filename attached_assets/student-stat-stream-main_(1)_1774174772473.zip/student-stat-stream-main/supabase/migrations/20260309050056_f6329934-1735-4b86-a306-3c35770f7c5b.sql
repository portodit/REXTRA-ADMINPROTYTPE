
-- ==========================================
-- TRIGGER: Topup status state machine
-- ==========================================
CREATE OR REPLACE FUNCTION validate_topup_status_transition()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        RETURN NEW;
    END IF;
    
    IF OLD.status IN ('FAILED', 'EXPIRED', 'REFUNDED') THEN
        RAISE EXCEPTION 'Cannot change status from terminal state: %', OLD.status;
    END IF;
    
    IF OLD.status = 'SUCCESS' AND NEW.status != 'REFUNDED' THEN
        RAISE EXCEPTION 'SUCCESS can only transition to REFUNDED';
    END IF;
    
    IF NEW.status = 'SUCCESS' AND NEW.paid_at IS NULL THEN
        RAISE EXCEPTION 'paid_at is required for SUCCESS status';
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_validate_topup_status
    BEFORE UPDATE ON topup_transaction
    FOR EACH ROW
    EXECUTE FUNCTION validate_topup_status_transition();

-- ==========================================
-- TRIGGER: Immutable ledger
-- ==========================================
CREATE OR REPLACE FUNCTION prevent_system_ledger_mutation()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'token_system_ledger is immutable. UPDATE and DELETE are not allowed. Use ADJUSTMENT entry for corrections.';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_immutable_system_ledger
    BEFORE UPDATE OR DELETE ON token_system_ledger
    FOR EACH ROW
    EXECUTE FUNCTION prevent_system_ledger_mutation();

-- ==========================================
-- STORED PROCEDURE: apply_topup_success
-- Credit token dari Top Up SUCCESS (idempotent)
-- ==========================================
CREATE OR REPLACE FUNCTION apply_topup_success(
    p_topup_id UUID,
    p_operator_id TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_user_id TEXT;
    v_token_amount BIGINT;
    v_status topup_status;
    v_paid_at TIMESTAMPTZ;
    v_invoice_id TEXT;
    v_existing_ledger_id UUID;
    v_balance_before BIGINT;
    v_balance_after BIGINT;
    v_ledger_id UUID;
    v_occurred_at TIMESTAMPTZ;
BEGIN
    SELECT user_id, token_amount, status, paid_at, invoice_id, ledger_id
    INTO v_user_id, v_token_amount, v_status, v_paid_at, v_invoice_id, v_existing_ledger_id
    FROM topup_transaction WHERE id = p_topup_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Topup transaction not found: %', p_topup_id;
    END IF;
    
    IF v_existing_ledger_id IS NOT NULL THEN
        RETURN v_existing_ledger_id;
    END IF;
    
    IF v_status != 'SUCCESS' THEN
        RAISE EXCEPTION 'Topup status must be SUCCESS, got: %', v_status;
    END IF;
    
    IF v_token_amount < 1 THEN
        RAISE EXCEPTION 'Token amount must be at least 1';
    END IF;
    
    INSERT INTO token_wallet (user_id, balance)
    VALUES (v_user_id, 0)
    ON CONFLICT (user_id) DO NOTHING;
    
    SELECT balance INTO v_balance_before
    FROM token_wallet WHERE user_id = v_user_id FOR UPDATE;
    
    v_balance_after := v_balance_before + v_token_amount;
    v_occurred_at := COALESCE(v_paid_at, NOW());
    
    BEGIN
        INSERT INTO token_system_ledger (
            occurred_at, user_id, direction, amount, balance_before, balance_after,
            source_type, source_id, reference_id, description, metadata, operator_id
        ) VALUES (
            v_occurred_at, v_user_id, 'IN', v_token_amount, v_balance_before, v_balance_after,
            'TOPUP', p_topup_id, v_invoice_id,
            'Top Up — ' || v_token_amount || ' Token',
            jsonb_build_object('invoice_id', v_invoice_id),
            p_operator_id
        ) RETURNING id INTO v_ledger_id;
    EXCEPTION WHEN unique_violation THEN
        SELECT id INTO v_ledger_id FROM token_system_ledger
        WHERE source_type = 'TOPUP' AND source_id = p_topup_id;
        RETURN v_ledger_id;
    END;
    
    UPDATE token_wallet
    SET balance = v_balance_after, updated_at = NOW(), last_ledger_id = v_ledger_id
    WHERE user_id = v_user_id;
    
    UPDATE topup_transaction
    SET ledger_id = v_ledger_id
    WHERE id = p_topup_id AND ledger_id IS NULL;
    
    RETURN v_ledger_id;
END;
$$;

-- ==========================================
-- STORED PROCEDURE: apply_membership_grant
-- Credit token dari benefit membership (idempotent)
-- ==========================================
CREATE OR REPLACE FUNCTION apply_membership_grant(
    p_user_id TEXT,
    p_token_amount BIGINT,
    p_reference_id TEXT,
    p_membership_source_id UUID DEFAULT NULL,
    p_operator_id TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_balance_before BIGINT;
    v_balance_after BIGINT;
    v_ledger_id UUID;
    v_existing_ledger_id UUID;
BEGIN
    IF p_token_amount < 1 THEN
        RAISE EXCEPTION 'Token amount must be at least 1';
    END IF;
    
    IF p_reference_id IS NULL OR p_reference_id = '' THEN
        RAISE EXCEPTION 'reference_id is required for membership grant';
    END IF;
    
    SELECT id INTO v_existing_ledger_id FROM token_system_ledger
    WHERE source_type = 'MEMBERSHIP' AND reference_id = p_reference_id;
    
    IF v_existing_ledger_id IS NOT NULL THEN
        RETURN v_existing_ledger_id;
    END IF;
    
    INSERT INTO token_wallet (user_id, balance)
    VALUES (p_user_id, 0)
    ON CONFLICT (user_id) DO NOTHING;
    
    SELECT balance INTO v_balance_before
    FROM token_wallet WHERE user_id = p_user_id FOR UPDATE;
    
    v_balance_after := v_balance_before + p_token_amount;
    
    BEGIN
        INSERT INTO token_system_ledger (
            occurred_at, user_id, direction, amount, balance_before, balance_after,
            source_type, source_id, reference_id, description, metadata, operator_id
        ) VALUES (
            NOW(), p_user_id, 'IN', p_token_amount, v_balance_before, v_balance_after,
            'MEMBERSHIP', p_membership_source_id, p_reference_id,
            'Membership Benefit — ' || p_token_amount || ' Token',
            jsonb_build_object('reference_id', p_reference_id),
            p_operator_id
        ) RETURNING id INTO v_ledger_id;
    EXCEPTION WHEN unique_violation THEN
        SELECT id INTO v_ledger_id FROM token_system_ledger
        WHERE source_type = 'MEMBERSHIP' AND reference_id = p_reference_id;
        RETURN v_ledger_id;
    END;
    
    UPDATE token_wallet
    SET balance = v_balance_after, updated_at = NOW(), last_ledger_id = v_ledger_id
    WHERE user_id = p_user_id;
    
    RETURN v_ledger_id;
END;
$$;

-- ==========================================
-- STORED PROCEDURE: apply_usage_spend
-- Debit token untuk konsumsi fitur (idempotent)
-- ==========================================
CREATE OR REPLACE FUNCTION apply_usage_spend(
    p_user_id TEXT,
    p_token_cost BIGINT,
    p_reference_id TEXT,
    p_entitlement_key TEXT,
    p_allow_negative BOOLEAN DEFAULT FALSE,
    p_usage_source_id UUID DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_balance_before BIGINT;
    v_balance_after BIGINT;
    v_ledger_id UUID;
    v_existing_ledger_id UUID;
BEGIN
    IF p_token_cost < 1 THEN
        RAISE EXCEPTION 'Token cost must be at least 1';
    END IF;
    
    IF p_reference_id IS NULL OR p_reference_id = '' THEN
        RAISE EXCEPTION 'reference_id is required for usage spend';
    END IF;
    
    SELECT id INTO v_existing_ledger_id FROM token_system_ledger
    WHERE source_type = 'USAGE' AND reference_id = p_reference_id;
    
    IF v_existing_ledger_id IS NOT NULL THEN
        RETURN v_existing_ledger_id;
    END IF;
    
    INSERT INTO token_wallet (user_id, balance)
    VALUES (p_user_id, 0)
    ON CONFLICT (user_id) DO NOTHING;
    
    SELECT balance INTO v_balance_before
    FROM token_wallet WHERE user_id = p_user_id FOR UPDATE;
    
    IF NOT p_allow_negative AND v_balance_before < p_token_cost THEN
        RAISE EXCEPTION 'Insufficient token balance. Required: %, Available: %', p_token_cost, v_balance_before;
    END IF;
    
    v_balance_after := v_balance_before - p_token_cost;
    
    BEGIN
        INSERT INTO token_system_ledger (
            occurred_at, user_id, direction, amount, balance_before, balance_after,
            source_type, source_id, reference_id, description, metadata
        ) VALUES (
            NOW(), p_user_id, 'OUT', p_token_cost, v_balance_before, v_balance_after,
            'USAGE', p_usage_source_id, p_reference_id,
            'Konsumsi Fitur — ' || p_entitlement_key,
            jsonb_build_object('entitlement_key', p_entitlement_key, 'allow_negative', p_allow_negative)
        ) RETURNING id INTO v_ledger_id;
    EXCEPTION WHEN unique_violation THEN
        SELECT id INTO v_ledger_id FROM token_system_ledger
        WHERE source_type = 'USAGE' AND reference_id = p_reference_id;
        RETURN v_ledger_id;
    END;
    
    UPDATE token_wallet
    SET balance = v_balance_after, updated_at = NOW(), last_ledger_id = v_ledger_id
    WHERE user_id = p_user_id;
    
    RETURN v_ledger_id;
END;
$$;

-- ==========================================
-- STORED PROCEDURE: save_custom_pricing_version
-- Simpan versi baru custom pricing (atomic + guardrail)
-- ==========================================
CREATE OR REPLACE FUNCTION save_custom_pricing_version(
    p_is_enabled BOOLEAN,
    p_min_token BIGINT,
    p_max_token BIGINT,
    p_recommended_price_per_token BIGINT,
    p_tiers JSONB,
    p_guardrail_ack BOOLEAN,
    p_updated_by TEXT
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_new_config_id UUID;
    v_tier JSONB;
    v_tier_discount NUMERIC;
    v_effective_price NUMERIC;
    v_threshold NUMERIC := 0.90;
    v_violations JSONB := '[]';
    v_violation JSONB;
BEGIN
    IF p_min_token < 1 THEN
        RAISE EXCEPTION 'min_token must be at least 1';
    END IF;
    
    IF p_max_token < 1 THEN
        RAISE EXCEPTION 'max_token must be at least 1';
    END IF;
    
    IF p_min_token >= p_max_token THEN
        RAISE EXCEPTION 'min_token must be less than max_token';
    END IF;
    
    IF p_recommended_price_per_token < 1 THEN
        RAISE EXCEPTION 'recommended_price_per_token must be at least 1';
    END IF;
    
    FOR v_tier IN SELECT * FROM jsonb_array_elements(p_tiers)
    LOOP
        v_tier_discount := (v_tier->>'discount_pct')::NUMERIC;
        v_effective_price := p_recommended_price_per_token * (1 - v_tier_discount / 100);
        
        IF v_effective_price < (p_recommended_price_per_token * v_threshold) THEN
            v_violation := jsonb_build_object(
                'range', (v_tier->>'from_token') || '-' || (v_tier->>'to_token'),
                'discount_pct', v_tier_discount,
                'effective_price', v_effective_price
            );
            v_violations := v_violations || v_violation;
        END IF;
    END LOOP;
    
    IF jsonb_array_length(v_violations) > 0 AND NOT p_guardrail_ack THEN
        RAISE EXCEPTION 'Guardrail violations detected. Violations: %', v_violations::TEXT;
    END IF;
    
    PERFORM id FROM custom_pricing_config WHERE is_current = TRUE FOR UPDATE;
    
    UPDATE custom_pricing_config
    SET is_current = FALSE, effective_to = NOW(), updated_at = NOW()
    WHERE is_current = TRUE;
    
    INSERT INTO custom_pricing_config (
        is_enabled, min_token, max_token, recommended_price_per_token,
        guardrail_ack_by, guardrail_ack_at, is_current, effective_from, updated_by, metadata
    ) VALUES (
        p_is_enabled, p_min_token, p_max_token, p_recommended_price_per_token,
        CASE WHEN jsonb_array_length(v_violations) > 0 THEN p_updated_by ELSE NULL END,
        CASE WHEN jsonb_array_length(v_violations) > 0 THEN NOW() ELSE NULL END,
        TRUE, NOW(), p_updated_by,
        jsonb_build_object('guardrail', jsonb_build_object('threshold', v_threshold, 'violations', v_violations))
    ) RETURNING id INTO v_new_config_id;
    
    FOR v_tier IN SELECT * FROM jsonb_array_elements(p_tiers)
    LOOP
        INSERT INTO custom_pricing_tier (config_id, from_token, to_token, discount_pct)
        VALUES (
            v_new_config_id,
            (v_tier->>'from_token')::BIGINT,
            (v_tier->>'to_token')::BIGINT,
            (v_tier->>'discount_pct')::NUMERIC
        );
    END LOOP;
    
    RETURN v_new_config_id;
END;
$$;
