
-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "btree_gist";

-- ==========================================
-- ENUMS
-- ==========================================
CREATE TYPE token_direction AS ENUM ('IN', 'OUT');
CREATE TYPE token_source_type AS ENUM ('TOPUP', 'MEMBERSHIP', 'USAGE', 'ADJUSTMENT', 'REFUND', 'EXPIRED');
CREATE TYPE topup_type AS ENUM ('BUNDLE', 'CUSTOM');
CREATE TYPE topup_status AS ENUM ('PENDING', 'SUCCESS', 'FAILED', 'EXPIRED', 'REFUNDED');

-- ==========================================
-- TABLE 1: token_wallet
-- Cache saldo token terkini per user
-- ==========================================
CREATE TABLE token_wallet (
    user_id TEXT PRIMARY KEY,
    balance BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_ledger_id UUID NULL
);

CREATE INDEX idx_tw_updated_at ON token_wallet(updated_at);
ALTER TABLE token_wallet ENABLE ROW LEVEL SECURITY;
CREATE POLICY "token_wallet_all" ON token_wallet FOR ALL USING (true) WITH CHECK (true);

-- ==========================================
-- TABLE 2: token_system_ledger
-- Audit trail immutable, source of truth
-- ==========================================
CREATE TABLE token_system_ledger (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    user_id TEXT NOT NULL,
    direction token_direction NOT NULL,
    amount BIGINT NOT NULL,
    balance_before BIGINT NOT NULL,
    balance_after BIGINT NOT NULL,
    source_type token_source_type NOT NULL,
    source_id UUID NULL,
    reference_id TEXT NULL,
    description TEXT NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}',
    operator_id TEXT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_sl_amount_positive CHECK (amount > 0)
);

-- Idempotency indexes
CREATE UNIQUE INDEX uq_sl_topup ON token_system_ledger (source_type, source_id) 
    WHERE source_type = 'TOPUP' AND source_id IS NOT NULL;
CREATE UNIQUE INDEX uq_sl_membership ON token_system_ledger (source_type, reference_id) 
    WHERE source_type = 'MEMBERSHIP' AND reference_id IS NOT NULL;
CREATE UNIQUE INDEX uq_sl_usage ON token_system_ledger (source_type, reference_id) 
    WHERE source_type = 'USAGE' AND reference_id IS NOT NULL;

-- Performance indexes
CREATE INDEX idx_sl_occurred ON token_system_ledger(occurred_at DESC);
CREATE INDEX idx_sl_user_occurred ON token_system_ledger(user_id, occurred_at DESC);
CREATE INDEX idx_sl_source_occurred ON token_system_ledger(source_type, occurred_at DESC);
CREATE INDEX idx_sl_direction_occurred ON token_system_ledger(direction, occurred_at DESC);
CREATE INDEX idx_sl_reference ON token_system_ledger(reference_id) WHERE reference_id IS NOT NULL;

-- FK from wallet to ledger
ALTER TABLE token_wallet
    ADD CONSTRAINT fk_wallet_last_ledger 
    FOREIGN KEY (last_ledger_id) 
    REFERENCES token_system_ledger(id) 
    ON DELETE SET NULL;

ALTER TABLE token_system_ledger ENABLE ROW LEVEL SECURITY;
CREATE POLICY "token_system_ledger_all" ON token_system_ledger FOR ALL USING (true) WITH CHECK (true);

-- ==========================================
-- TABLE 3: token_bundle_package
-- Master data paket Top Up
-- ==========================================
CREATE TABLE token_bundle_package (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(50) UNIQUE NOT NULL,
    token_amount BIGINT NOT NULL,
    price_rp BIGINT NOT NULL,
    label VARCHAR(30) NULL,
    display_order INT NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_bp_token_positive CHECK (token_amount >= 1),
    CONSTRAINT chk_bp_price_positive CHECK (price_rp >= 1)
);

CREATE INDEX idx_bp_active_order ON token_bundle_package(is_active, display_order);
CREATE INDEX idx_bp_created ON token_bundle_package(created_at DESC);

ALTER TABLE token_bundle_package ENABLE ROW LEVEL SECURITY;
CREATE POLICY "token_bundle_package_all" ON token_bundle_package FOR ALL USING (true) WITH CHECK (true);

-- ==========================================
-- TABLE 4: topup_transaction
-- Pipeline transaksi pengadaan token
-- ==========================================
CREATE TABLE topup_transaction (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    type topup_type NOT NULL,
    bundle_package_id UUID NULL REFERENCES token_bundle_package(id) ON DELETE RESTRICT,
    token_amount BIGINT NOT NULL,
    total_price_rp BIGINT NOT NULL,
    status topup_status NOT NULL DEFAULT 'PENDING',
    invoice_id TEXT UNIQUE NOT NULL,
    provider VARCHAR(30) NULL,
    paid_at TIMESTAMPTZ NULL,
    expired_at TIMESTAMPTZ NULL,
    ledger_id UUID NULL REFERENCES token_system_ledger(id) ON DELETE RESTRICT,
    metadata JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_tt_token_positive CHECK (token_amount >= 1),
    CONSTRAINT chk_tt_price_positive CHECK (total_price_rp >= 1),
    CONSTRAINT chk_tt_type_consistency CHECK (
        (type = 'BUNDLE' AND bundle_package_id IS NOT NULL) OR
        (type = 'CUSTOM' AND bundle_package_id IS NULL)
    )
);

CREATE UNIQUE INDEX uq_tt_ledger ON topup_transaction(ledger_id) WHERE ledger_id IS NOT NULL;
CREATE INDEX idx_tt_created ON topup_transaction(created_at DESC);
CREATE INDEX idx_tt_status_created ON topup_transaction(status, created_at DESC);
CREATE INDEX idx_tt_user_created ON topup_transaction(user_id, created_at DESC);

ALTER TABLE topup_transaction ENABLE ROW LEVEL SECURITY;
CREATE POLICY "topup_transaction_all" ON topup_transaction FOR ALL USING (true) WITH CHECK (true);

-- ==========================================
-- TABLE 5: custom_pricing_config
-- Konfigurasi harga custom (versioned)
-- ==========================================
CREATE TABLE custom_pricing_config (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    is_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    min_token BIGINT NOT NULL,
    max_token BIGINT NOT NULL,
    recommended_price_per_token BIGINT NOT NULL,
    guardrail_ack_by TEXT NULL,
    guardrail_ack_at TIMESTAMPTZ NULL,
    is_current BOOLEAN NOT NULL DEFAULT FALSE,
    effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    effective_to TIMESTAMPTZ NULL,
    updated_by TEXT NULL,
    metadata JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_cpc_min_positive CHECK (min_token >= 1),
    CONSTRAINT chk_cpc_max_positive CHECK (max_token >= 1),
    CONSTRAINT chk_cpc_min_lt_max CHECK (min_token < max_token),
    CONSTRAINT chk_cpc_price_positive CHECK (recommended_price_per_token >= 1)
);

CREATE UNIQUE INDEX uq_cpc_current ON custom_pricing_config (is_current) WHERE is_current = TRUE;
CREATE INDEX idx_cpc_effective ON custom_pricing_config(effective_from DESC);

ALTER TABLE custom_pricing_config ENABLE ROW LEVEL SECURITY;
CREATE POLICY "custom_pricing_config_all" ON custom_pricing_config FOR ALL USING (true) WITH CHECK (true);

-- ==========================================
-- TABLE 6: custom_pricing_tier
-- Tier diskon bertingkat
-- ==========================================
CREATE TABLE custom_pricing_tier (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    config_id UUID NOT NULL REFERENCES custom_pricing_config(id) ON DELETE RESTRICT,
    from_token BIGINT NOT NULL,
    to_token BIGINT NOT NULL,
    discount_pct NUMERIC(5,2) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT chk_cpt_from_positive CHECK (from_token >= 1),
    CONSTRAINT chk_cpt_to_positive CHECK (to_token >= 1),
    CONSTRAINT chk_cpt_from_lte_to CHECK (from_token <= to_token),
    CONSTRAINT chk_cpt_discount_range CHECK (discount_pct >= 0 AND discount_pct <= 100)
);

CREATE INDEX idx_cpt_config_from ON custom_pricing_tier(config_id, from_token ASC);

ALTER TABLE custom_pricing_tier ENABLE ROW LEVEL SECURITY;
CREATE POLICY "custom_pricing_tier_all" ON custom_pricing_tier FOR ALL USING (true) WITH CHECK (true);
