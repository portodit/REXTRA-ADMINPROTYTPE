-- Helper to gate export action
create or replace function public.check_user_can_export_database()
returns boolean
language sql
stable
security invoker
set search_path = public
as $$
  select auth.uid() is not null;
$$;

-- Export SQL text containing only rows visible to the current authenticated user (RLS-aware)
create or replace function public.export_accessible_data_sql()
returns text
language plpgsql
stable
security invoker
set search_path = public
as $$
declare
  t record;
  rows_json jsonb;
  output_sql text := '-- Lovable Cloud SQL export (RLS-aware)' || E'\n' || '-- Generated at: ' || now()::text || E'\n';
begin
  if auth.uid() is null then
    raise exception 'Unauthorized';
  end if;

  for t in
    select schemaname, tablename
    from pg_tables
    where schemaname = 'public'
      and tablename not like 'pg_%'
      and tablename not like 'sql_%'
    order by tablename
  loop
    begin
      execute format(
        'select coalesce(jsonb_agg(to_jsonb(r)), ''[]''::jsonb) from (select * from %I.%I) r',
        t.schemaname,
        t.tablename
      ) into rows_json;
    exception
      when others then
        continue;
    end;

    output_sql := output_sql || E'\n' || format('-- Table: %I.%I', t.schemaname, t.tablename) || E'\n';

    if jsonb_array_length(rows_json) = 0 then
      output_sql := output_sql || '-- no rows' || E'\n';
    else
      output_sql := output_sql || format(
        'insert into %I.%I select * from jsonb_populate_recordset(null::%I.%I, %L::jsonb);',
        t.schemaname,
        t.tablename,
        t.schemaname,
        t.tablename,
        rows_json::text
      ) || E'\n';
    end if;
  end loop;

  return output_sql;
end;
$$;

revoke all on function public.check_user_can_export_database() from public;
revoke all on function public.export_accessible_data_sql() from public;

grant execute on function public.check_user_can_export_database() to authenticated;
grant execute on function public.export_accessible_data_sql() to authenticated;