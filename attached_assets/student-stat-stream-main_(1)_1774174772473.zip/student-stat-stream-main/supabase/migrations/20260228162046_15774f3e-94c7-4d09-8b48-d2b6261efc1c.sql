
-- Features table (Fitur)
CREATE TABLE public.features (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  prefix text NOT NULL UNIQUE,
  type text NOT NULL DEFAULT 'tunggal' CHECK (type IN ('tunggal', 'bertingkat')),
  description text DEFAULT '',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Sub-features table (Sub Fitur)
CREATE TABLE public.sub_features (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  feature_id uuid NOT NULL REFERENCES public.features(id) ON DELETE CASCADE,
  name text NOT NULL,
  slug text NOT NULL,
  tipe_akses text NOT NULL DEFAULT 'unlimited' CHECK (tipe_akses IN ('unlimited', 'frequency_limited', 'token_gated')),
  description text DEFAULT '',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(feature_id, slug)
);

-- Action categories (Kategori Aksi)
CREATE TABLE public.action_categories (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL UNIQUE,
  slug text NOT NULL UNIQUE,
  description text DEFAULT '',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Entitlements (Hak Akses)
CREATE TABLE public.entitlements (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  key text NOT NULL UNIQUE,
  level text NOT NULL DEFAULT 'fitur' CHECK (level IN ('fitur', 'sub_fitur')),
  feature_id uuid NOT NULL REFERENCES public.features(id) ON DELETE CASCADE,
  sub_feature_id uuid REFERENCES public.sub_features(id) ON DELETE CASCADE,
  action_category_id uuid NOT NULL REFERENCES public.action_categories(id) ON DELETE CASCADE,
  description text DEFAULT '',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- RLS policies (public access for admin panel V1)
ALTER TABLE public.features ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sub_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.action_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.entitlements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "features_all" ON public.features FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "sub_features_all" ON public.sub_features FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "action_categories_all" ON public.action_categories FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "entitlements_all" ON public.entitlements FOR ALL USING (true) WITH CHECK (true);

-- Seed: Features
INSERT INTO public.features (id, name, slug, prefix, type, description, status) VALUES
  ('a1000000-0000-0000-0000-000000000001', 'Kamus Karier', 'kamus_karier', 'kk', 'bertingkat', 'Fitur eksplorasi karier & profesi', 'active'),
  ('a1000000-0000-0000-0000-000000000002', 'CV Generator', 'cv_generator', 'cv', 'tunggal', 'Fitur untuk membuat CV otomatis', 'active'),
  ('a1000000-0000-0000-0000-000000000003', 'Portfolio', 'portfolio', 'pf', 'bertingkat', 'Fitur untuk mengelola portfolio mahasiswa', 'active'),
  ('a1000000-0000-0000-0000-000000000004', 'Kenali Diri', 'kenali_diri', 'kd', 'tunggal', 'Asesmen kepribadian dan minat bakat', 'inactive');

-- Seed: Sub-features
INSERT INTO public.sub_features (id, feature_id, name, slug, tipe_akses, status) VALUES
  ('b1000000-0000-0000-0000-000000000001', 'a1000000-0000-0000-0000-000000000001', 'Jelajah Profesi', 'jelajah_profesi', 'unlimited', 'active'),
  ('b1000000-0000-0000-0000-000000000002', 'a1000000-0000-0000-0000-000000000001', 'Uji Kecocokan', 'uji_kecocokan', 'token_gated', 'active'),
  ('b1000000-0000-0000-0000-000000000003', 'a1000000-0000-0000-0000-000000000001', 'Bandingkan Profesi', 'bandingkan_profesi', 'frequency_limited', 'active'),
  ('b1000000-0000-0000-0000-000000000004', 'a1000000-0000-0000-0000-000000000003', 'Auto-fill Portfolio', 'auto_fill', 'token_gated', 'active'),
  ('b1000000-0000-0000-0000-000000000005', 'a1000000-0000-0000-0000-000000000003', 'AI Check Portfolio', 'ai_check', 'token_gated', 'active');

-- Seed: Action Categories
INSERT INTO public.action_categories (id, name, slug, description, status) VALUES
  ('c1000000-0000-0000-0000-000000000001', 'Tampilan', 'view', 'Akses untuk melihat data atau halaman', 'active'),
  ('c1000000-0000-0000-0000-000000000002', 'Pembuatan', 'create', 'Akses untuk membuat data baru', 'active'),
  ('c1000000-0000-0000-0000-000000000003', 'Penggunaan', 'use', 'Akses untuk menggunakan fitur', 'active'),
  ('c1000000-0000-0000-0000-000000000004', 'Pengeditan', 'edit', 'Akses untuk mengubah data', 'active'),
  ('c1000000-0000-0000-0000-000000000005', 'Penghapusan', 'delete', 'Akses untuk menghapus data', 'inactive');

-- Seed: Entitlements
INSERT INTO public.entitlements (name, key, level, feature_id, sub_feature_id, action_category_id, description, status) VALUES
  ('Lihat Kamus Karier', 'kk.view', 'fitur', 'a1000000-0000-0000-0000-000000000001', NULL, 'c1000000-0000-0000-0000-000000000001', 'Melihat halaman kamus karier', 'active'),
  ('Gunakan Kamus Karier', 'kk.use', 'fitur', 'a1000000-0000-0000-0000-000000000001', NULL, 'c1000000-0000-0000-0000-000000000003', 'Menggunakan fitur kamus karier', 'active'),
  ('Lihat Jelajah Profesi', 'kk.jelajah_profesi.view', 'sub_fitur', 'a1000000-0000-0000-0000-000000000001', 'b1000000-0000-0000-0000-000000000001', 'c1000000-0000-0000-0000-000000000001', 'Melihat halaman jelajah profesi', 'active'),
  ('Gunakan Jelajah Profesi', 'kk.jelajah_profesi.use', 'sub_fitur', 'a1000000-0000-0000-0000-000000000001', 'b1000000-0000-0000-0000-000000000001', 'c1000000-0000-0000-0000-000000000003', 'Menggunakan fitur jelajah profesi', 'active'),
  ('Gunakan Uji Kecocokan', 'kk.uji_kecocokan.use', 'sub_fitur', 'a1000000-0000-0000-0000-000000000001', 'b1000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000003', 'Menggunakan fitur uji kecocokan', 'active'),
  ('Gunakan Bandingkan Profesi', 'kk.bandingkan_profesi.use', 'sub_fitur', 'a1000000-0000-0000-0000-000000000001', 'b1000000-0000-0000-0000-000000000003', 'c1000000-0000-0000-0000-000000000003', 'Menggunakan fitur bandingkan profesi', 'active'),
  ('Lihat CV Generator', 'cv.view', 'fitur', 'a1000000-0000-0000-0000-000000000002', NULL, 'c1000000-0000-0000-0000-000000000001', 'Melihat halaman CV Generator', 'active'),
  ('Buat CV', 'cv.create', 'fitur', 'a1000000-0000-0000-0000-000000000002', NULL, 'c1000000-0000-0000-0000-000000000002', 'Membuat CV baru', 'active'),
  ('Lihat Portfolio', 'pf.view', 'fitur', 'a1000000-0000-0000-0000-000000000003', NULL, 'c1000000-0000-0000-0000-000000000001', 'Melihat halaman portfolio', 'active'),
  ('Gunakan Auto-fill Portfolio', 'pf.auto_fill.use', 'sub_fitur', 'a1000000-0000-0000-0000-000000000003', 'b1000000-0000-0000-0000-000000000004', 'c1000000-0000-0000-0000-000000000003', 'Menggunakan fitur auto-fill', 'active'),
  ('Gunakan AI Check Portfolio', 'pf.ai_check.use', 'sub_fitur', 'a1000000-0000-0000-0000-000000000003', 'b1000000-0000-0000-0000-000000000005', 'c1000000-0000-0000-0000-000000000003', 'Menggunakan fitur AI Check', 'active'),
  ('Buat Portfolio', 'pf.create', 'fitur', 'a1000000-0000-0000-0000-000000000003', NULL, 'c1000000-0000-0000-0000-000000000002', 'Membuat portfolio baru', 'inactive');

-- Add foreign key for duration_access_mappings to entitlements (optional link)
ALTER TABLE public.duration_access_mappings ADD COLUMN IF NOT EXISTS entitlement_id uuid REFERENCES public.entitlements(id) ON DELETE SET NULL;
