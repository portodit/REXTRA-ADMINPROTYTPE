-- Standard should always be tanpa_durasi (no duration)
UPDATE membership_plans SET duration_mode = 'tanpa_durasi' WHERE id = 'standard';

-- Starter uses a single configurable duration, not the 1/3/6/12 system
UPDATE membership_plans SET duration_mode = 'starter_durasi' WHERE id = 'starter';

-- Ensure starter has exactly 1 plan_duration record (if not exists)
INSERT INTO plan_durations (plan_id, duration_months, is_active, price, final_price, duration_price, token_amount, bonus_token, points_active, points_value, bonus_points, discount_percent)
SELECT 'starter', 1, true, 0, 0, 0, 0, 0, false, 0, 0, 0
WHERE NOT EXISTS (SELECT 1 FROM plan_durations WHERE plan_id = 'starter' LIMIT 1);

-- Standard should have exactly 1 plan_duration for access mapping purposes (universal, duration_months=0 means no duration)
INSERT INTO plan_durations (plan_id, duration_months, is_active, price, final_price, duration_price, token_amount, bonus_token, points_active, points_value, bonus_points, discount_percent)
SELECT 'standard', 0, true, 0, 0, 0, 0, 0, false, 0, 0, 0
WHERE NOT EXISTS (SELECT 1 FROM plan_durations WHERE plan_id = 'standard' LIMIT 1);