
-- Discounts table
CREATE TABLE public.discounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  status text NOT NULL DEFAULT 'ACTIVE',
  starts_at timestamptz,
  ends_at timestamptz,
  applies_to text NOT NULL DEFAULT 'GLOBAL',
  membership_plan_targets text[],
  topup_targets text[],
  discount_type text NOT NULL DEFAULT 'PERCENTAGE',
  value integer NOT NULL DEFAULT 0,
  max_discount_amount integer,
  min_purchase_amount integer,
  max_total_redemptions integer,
  max_redemptions_per_user integer,
  stackable boolean NOT NULL DEFAULT false,
  priority integer NOT NULL DEFAULT 100,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by text DEFAULT 'System',
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by text DEFAULT 'System'
);

ALTER TABLE public.discounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "discounts_all" ON public.discounts FOR ALL USING (true) WITH CHECK (true);

-- Discount redemptions ledger
CREATE TABLE public.discount_redemptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  discount_id uuid NOT NULL REFERENCES public.discounts(id) ON DELETE CASCADE,
  code_snapshot text NOT NULL,
  user_id text NOT NULL,
  user_name text,
  transaction_id text,
  applies_to_type text NOT NULL,
  plan_snapshot text,
  subtotal_amount integer NOT NULL DEFAULT 0,
  discount_amount integer NOT NULL DEFAULT 0,
  final_amount integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'APPLIED',
  applied_at timestamptz NOT NULL DEFAULT now(),
  reversed_at timestamptz,
  reverse_reason text
);

ALTER TABLE public.discount_redemptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "discount_redemptions_all" ON public.discount_redemptions FOR ALL USING (true) WITH CHECK (true);
