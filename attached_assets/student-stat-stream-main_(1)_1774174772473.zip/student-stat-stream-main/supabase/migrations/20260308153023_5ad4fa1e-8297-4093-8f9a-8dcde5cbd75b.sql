
ALTER TABLE public.entitlements
  ADD COLUMN IF NOT EXISTS restriction_type text NOT NULL DEFAULT 'unlimited',
  ADD COLUMN IF NOT EXISTS token_cost integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS usage_limit integer DEFAULT 0;
