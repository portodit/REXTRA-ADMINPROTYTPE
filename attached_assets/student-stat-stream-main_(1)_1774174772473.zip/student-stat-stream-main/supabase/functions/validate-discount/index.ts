import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const body = await req.json();
    const { code, user_id, order, existing_codes } = body;

    if (!code || !order?.type || !order?.subtotal_amount) {
      return new Response(JSON.stringify({ valid: false, reason: "INVALID_REQUEST" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    // Fetch discount
    const { data: discount, error } = await supabase
      .from("discounts")
      .select("*")
      .eq("code", code.toUpperCase())
      .single();

    if (error || !discount) {
      return json({ valid: false, discount: null, final_amount: null, reason: "CODE_NOT_FOUND" });
    }

    const now = new Date();

    // Status check
    if (discount.status !== "ACTIVE") {
      return json({ valid: false, discount: null, final_amount: null, reason: "CODE_INACTIVE" });
    }

    // Date checks
    if (discount.starts_at && new Date(discount.starts_at) > now) {
      return json({ valid: false, discount: null, final_amount: null, reason: "CODE_NOT_STARTED" });
    }
    if (discount.ends_at && new Date(discount.ends_at) < now) {
      return json({ valid: false, discount: null, final_amount: null, reason: "CODE_EXPIRED" });
    }

    // Scope check
    const orderType = order.type; // MEMBERSHIP or TOKEN_TOPUP
    if (discount.applies_to !== "GLOBAL" && discount.applies_to !== orderType) {
      return json({ valid: false, discount: null, final_amount: null, reason: "CODE_NOT_APPLICABLE_TO_ORDER_TYPE" });
    }

    // Plan check for membership
    if (orderType === "MEMBERSHIP" && discount.membership_plan_targets && discount.membership_plan_targets.length > 0) {
      if (!discount.membership_plan_targets.includes(order.plan)) {
        return json({ valid: false, discount: null, final_amount: null, reason: "CODE_NOT_APPLICABLE_TO_PLAN" });
      }
    }

    // Min purchase check
    if (discount.min_purchase_amount && order.subtotal_amount < discount.min_purchase_amount) {
      return json({ valid: false, discount: null, final_amount: null, reason: "MIN_PURCHASE_NOT_MET" });
    }

    // Stacking check
    if (!discount.stackable && existing_codes && existing_codes.length > 0) {
      return json({ valid: false, discount: null, final_amount: null, reason: "STACKING_NOT_ALLOWED" });
    }

    // Total redemptions check
    if (discount.max_total_redemptions) {
      const { count } = await supabase
        .from("discount_redemptions")
        .select("id", { count: "exact", head: true })
        .eq("discount_id", discount.id)
        .eq("status", "APPLIED");
      if ((count || 0) >= discount.max_total_redemptions) {
        return json({ valid: false, discount: null, final_amount: null, reason: "MAX_TOTAL_REDEMPTIONS_REACHED" });
      }
    }

    // Per-user redemptions check
    if (discount.max_redemptions_per_user && user_id) {
      const { count } = await supabase
        .from("discount_redemptions")
        .select("id", { count: "exact", head: true })
        .eq("discount_id", discount.id)
        .eq("user_id", user_id)
        .eq("status", "APPLIED");
      if ((count || 0) >= discount.max_redemptions_per_user) {
        return json({ valid: false, discount: null, final_amount: null, reason: "MAX_PER_USER_REDEMPTIONS_REACHED" });
      }
    }

    // Calculate discount amount
    let discountAmount = 0;
    if (discount.discount_type === "PERCENTAGE") {
      discountAmount = Math.floor(order.subtotal_amount * discount.value / 100);
      if (discount.max_discount_amount && discountAmount > discount.max_discount_amount) {
        discountAmount = discount.max_discount_amount;
      }
    } else {
      discountAmount = discount.value;
    }

    if (discountAmount > order.subtotal_amount) {
      discountAmount = order.subtotal_amount;
    }

    const finalAmount = order.subtotal_amount - discountAmount;

    return json({
      valid: true,
      discount: {
        code: discount.code,
        discount_type: discount.discount_type,
        value: discount.value,
        discount_amount: discountAmount,
        max_discount_amount: discount.max_discount_amount,
      },
      final_amount: finalAmount,
      reason: null,
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});

function json(data: Record<string, unknown>) {
  return new Response(JSON.stringify(data), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
