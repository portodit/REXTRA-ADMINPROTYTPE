# Spesifikasi Backend: Halaman Pengaturan Membership

> Dokumen ini menjelaskan logic backend dalam bahasa **Go (Golang)** untuk halaman **Pengaturan Membership** yang terdiri dari 2 modul:
> 1. **Notifikasi Pengingat Expired**
> 2. **Dokumen & Penomoran**

---

## 1. Database Schema

### 1.1 Tabel `membership_notification_settings`

```sql
CREATE TABLE membership_notification_settings (
    id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    is_enabled             BOOLEAN NOT NULL DEFAULT false,
    triggers               TEXT[] NOT NULL DEFAULT '{}',        -- contoh: {"D7","D3","D1"}
    email_subject_template TEXT NOT NULL DEFAULT '',
    email_body_template    TEXT NOT NULL DEFAULT '',
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by             TEXT
);
```

**Catatan:** Tabel ini hanya berisi **1 row** (singleton config). Gunakan `LIMIT 1` saat query.

### 1.2 Tabel `invoice_settings`

```sql
CREATE TABLE invoice_settings (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_name       TEXT NOT NULL DEFAULT 'Rextra',
    company_address    TEXT,
    footer_text        TEXT NOT NULL DEFAULT 'Dokumen ini dibuat secara otomatis oleh sistem.',
    default_due_days   INTEGER NOT NULL DEFAULT 0,
    base_invoice_url   TEXT,
    notes              TEXT[] DEFAULT '{}',           -- bullet points informasi tambahan
    invoice_prefix     TEXT NOT NULL DEFAULT 'INV',
    invoice_reset_rule TEXT NOT NULL DEFAULT 'MONTHLY', -- MONTHLY | YEARLY | NONE
    invoice_title      TEXT DEFAULT 'FAKTUR',
    logo_url           TEXT,
    terms_content      TEXT,
    email_footer_text  TEXT,                          -- dipakai modul notifikasi juga
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by         TEXT
);
```

### 1.3 Tabel `transaction_id_settings`

```sql
CREATE TABLE transaction_id_settings (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trx_prefix  TEXT NOT NULL DEFAULT 'TRX',
    trx_pattern TEXT NOT NULL DEFAULT 'DATE_DAILY', -- DATE_DAILY | DATE_MONTHLY | GLOBAL_SEQ
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by  TEXT
);
```

---

## 2. Go Structs

```go
package model

import "time"

// ── Notification ──

type NotificationSettings struct {
    ID                   string    `json:"id" db:"id"`
    IsEnabled            bool      `json:"is_enabled" db:"is_enabled"`
    Triggers             []string  `json:"triggers" db:"triggers"`              // ["D7","D3","D1"]
    EmailSubjectTemplate string    `json:"email_subject_template" db:"email_subject_template"`
    EmailBodyTemplate    string    `json:"email_body_template" db:"email_body_template"`
    UpdatedAt            time.Time `json:"updated_at" db:"updated_at"`
    UpdatedBy            *string   `json:"updated_by" db:"updated_by"`
}

// ── Invoice / Dokumen ──

type InvoiceSettings struct {
    ID               string    `json:"id" db:"id"`
    CompanyName      string    `json:"company_name" db:"company_name"`
    CompanyAddress   *string   `json:"company_address" db:"company_address"`
    FooterText       string    `json:"footer_text" db:"footer_text"`
    DefaultDueDays   int       `json:"default_due_days" db:"default_due_days"`
    BaseInvoiceURL   *string   `json:"base_invoice_url" db:"base_invoice_url"`
    Notes            []string  `json:"notes" db:"notes"`
    InvoicePrefix    string    `json:"invoice_prefix" db:"invoice_prefix"`
    InvoiceResetRule string    `json:"invoice_reset_rule" db:"invoice_reset_rule"` // MONTHLY|YEARLY|NONE
    InvoiceTitle     *string   `json:"invoice_title" db:"invoice_title"`
    LogoURL          *string   `json:"logo_url" db:"logo_url"`
    TermsContent     *string   `json:"terms_content" db:"terms_content"`
    EmailFooterText  *string   `json:"email_footer_text" db:"email_footer_text"`
    UpdatedAt        time.Time `json:"updated_at" db:"updated_at"`
    UpdatedBy        *string   `json:"updated_by" db:"updated_by"`
}

// ── Transaction ID ──

type TransactionIDSettings struct {
    ID         string    `json:"id" db:"id"`
    TrxPrefix  string    `json:"trx_prefix" db:"trx_prefix"`
    TrxPattern string    `json:"trx_pattern" db:"trx_pattern"` // DATE_DAILY|DATE_MONTHLY|GLOBAL_SEQ
    UpdatedAt  time.Time `json:"updated_at" db:"updated_at"`
    UpdatedBy  *string   `json:"updated_by" db:"updated_by"`
}
```

---

## 3. REST API Endpoints

| Method | Path | Deskripsi |
|--------|------|-----------|
| `GET`  | `/api/v1/settings/notification` | Ambil pengaturan notifikasi |
| `PATCH`| `/api/v1/settings/notification` | Update sebagian field notifikasi |
| `GET`  | `/api/v1/settings/invoice` | Ambil pengaturan dokumen/invoice |
| `PATCH`| `/api/v1/settings/invoice` | Update sebagian field invoice |
| `GET`  | `/api/v1/settings/transaction-id` | Ambil pengaturan format ID transaksi |
| `PATCH`| `/api/v1/settings/transaction-id` | Update sebagian field TRX ID |
| `POST` | `/api/v1/settings/document/reset` | Reset dokumen & TRX ID ke default |

### 3.1 Request/Response Examples

**PATCH `/api/v1/settings/notification`**
```json
// Request
{
  "is_enabled": true,
  "triggers": ["D7", "D3"],
  "email_subject_template": "Membership kamu akan berakhir {sisa_hari} hari lagi",
  "email_body_template": "Halo {nama_depan}, membership {nama_plan} kamu berakhir pada {tanggal_berakhir}."
}

// Response 200
{
  "success": true,
  "data": { /* NotificationSettings lengkap */ }
}
```

**PATCH `/api/v1/settings/invoice`**
```json
// Request (partial update)
{
  "company_name": "Rextra Technology",
  "invoice_prefix": "INV",
  "invoice_reset_rule": "MONTHLY",
  "notes": ["Pembayaran tidak dapat dikembalikan", "Hubungi cs@rextra.id"],
  "email_footer_text": "© 2026 Rextra · Email otomatis"
}
```

---

## 4. Handler Logic (Go)

### 4.1 Fetch Settings (Singleton Pattern)

```go
package handler

import (
    "net/http"
    "encoding/json"
    "yourapp/model"
    "yourapp/repository"
)

func GetNotificationSettings(w http.ResponseWriter, r *http.Request) {
    settings, err := repository.GetNotificationSettings(r.Context())
    if err != nil {
        http.Error(w, "gagal mengambil data", http.StatusInternalServerError)
        return
    }
    json.NewEncoder(w).Encode(map[string]any{
        "success": true,
        "data":    settings,
    })
}
```

### 4.2 Update Settings (Partial Update / PATCH)

```go
type UpdateNotificationRequest struct {
    IsEnabled            *bool     `json:"is_enabled"`
    Triggers             *[]string `json:"triggers"`
    EmailSubjectTemplate *string   `json:"email_subject_template"`
    EmailBodyTemplate    *string   `json:"email_body_template"`
}

func UpdateNotificationSettings(w http.ResponseWriter, r *http.Request) {
    var req UpdateNotificationRequest
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, "invalid JSON", http.StatusBadRequest)
        return
    }

    // Validasi: jika is_enabled=true, triggers & template wajib terisi
    if req.IsEnabled != nil && *req.IsEnabled {
        if req.Triggers != nil && len(*req.Triggers) == 0 {
            http.Error(w, "triggers wajib diisi jika notifikasi diaktifkan", http.StatusUnprocessableEntity)
            return
        }
        if req.EmailSubjectTemplate != nil && *req.EmailSubjectTemplate == "" {
            http.Error(w, "email subject wajib diisi", http.StatusUnprocessableEntity)
            return
        }
        if req.EmailBodyTemplate != nil && *req.EmailBodyTemplate == "" {
            http.Error(w, "email body wajib diisi", http.StatusUnprocessableEntity)
            return
        }
    }

    // Validasi trigger values
    validTriggers := map[string]bool{"D7": true, "D3": true, "D1": true}
    if req.Triggers != nil {
        for _, t := range *req.Triggers {
            if !validTriggers[t] {
                http.Error(w, "trigger tidak valid: "+t, http.StatusUnprocessableEntity)
                return
            }
        }
    }

    operatorID := r.Context().Value("user_id").(string) // dari auth middleware
    updated, err := repository.UpdateNotificationSettings(r.Context(), req, operatorID)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }
    json.NewEncoder(w).Encode(map[string]any{"success": true, "data": updated})
}
```

### 4.3 Update Invoice Settings

```go
type UpdateInvoiceRequest struct {
    CompanyName      *string   `json:"company_name"`
    CompanyAddress   *string   `json:"company_address"`
    FooterText       *string   `json:"footer_text"`
    DefaultDueDays   *int      `json:"default_due_days"`
    Notes            *[]string `json:"notes"`
    InvoicePrefix    *string   `json:"invoice_prefix"`
    InvoiceResetRule *string   `json:"invoice_reset_rule"`
    InvoiceTitle     *string   `json:"invoice_title"`
    TermsContent     *string   `json:"terms_content"`
    EmailFooterText  *string   `json:"email_footer_text"`
}

func UpdateInvoiceSettings(w http.ResponseWriter, r *http.Request) {
    var req UpdateInvoiceRequest
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, "invalid JSON", http.StatusBadRequest)
        return
    }

    // Validasi invoice_reset_rule
    if req.InvoiceResetRule != nil {
        validRules := map[string]bool{"MONTHLY": true, "YEARLY": true, "NONE": true}
        if !validRules[*req.InvoiceResetRule] {
            http.Error(w, "invoice_reset_rule tidak valid", http.StatusUnprocessableEntity)
            return
        }
    }

    // Validasi prefix harus uppercase, max 10 chars
    if req.InvoicePrefix != nil {
        prefix := strings.ToUpper(strings.TrimSpace(*req.InvoicePrefix))
        if len(prefix) == 0 || len(prefix) > 10 {
            http.Error(w, "prefix harus 1-10 karakter", http.StatusUnprocessableEntity)
            return
        }
        req.InvoicePrefix = &prefix
    }

    // Bersihkan notes kosong
    if req.Notes != nil {
        cleaned := make([]string, 0)
        for _, n := range *req.Notes {
            if strings.TrimSpace(n) != "" {
                cleaned = append(cleaned, n)
            }
        }
        req.Notes = &cleaned
    }

    operatorID := r.Context().Value("user_id").(string)
    updated, err := repository.UpdateInvoiceSettings(r.Context(), req, operatorID)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }
    json.NewEncoder(w).Encode(map[string]any{"success": true, "data": updated})
}
```

### 4.4 Update Transaction ID Settings

```go
type UpdateTransactionIDRequest struct {
    TrxPrefix  *string `json:"trx_prefix"`
    TrxPattern *string `json:"trx_pattern"`
}

func UpdateTransactionIDSettings(w http.ResponseWriter, r *http.Request) {
    var req UpdateTransactionIDRequest
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, "invalid JSON", http.StatusBadRequest)
        return
    }

    // Validasi pattern
    if req.TrxPattern != nil {
        validPatterns := map[string]bool{
            "DATE_DAILY":   true,
            "DATE_MONTHLY": true,
            "GLOBAL_SEQ":   true,
        }
        if !validPatterns[*req.TrxPattern] {
            http.Error(w, "trx_pattern tidak valid", http.StatusUnprocessableEntity)
            return
        }
    }

    // Uppercase prefix
    if req.TrxPrefix != nil {
        p := strings.ToUpper(strings.TrimSpace(*req.TrxPrefix))
        req.TrxPrefix = &p
    }

    operatorID := r.Context().Value("user_id").(string)
    updated, err := repository.UpdateTransactionIDSettings(r.Context(), req, operatorID)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }
    json.NewEncoder(w).Encode(map[string]any{"success": true, "data": updated})
}
```

### 4.5 Reset ke Default

```go
func ResetDocumentDefaults(w http.ResponseWriter, r *http.Request) {
    operatorID := r.Context().Value("user_id").(string)

    // Reset invoice_settings
    defaultInvoice := UpdateInvoiceRequest{
        CompanyName:      strPtr("Rextra"),
        FooterText:       strPtr("Dokumen ini dibuat secara otomatis oleh sistem."),
        DefaultDueDays:   intPtr(0),
        Notes:            &[]string{},
        InvoicePrefix:    strPtr("INV"),
        InvoiceResetRule: strPtr("MONTHLY"),
        TermsContent:     strPtr(""),
    }
    _, err := repository.UpdateInvoiceSettings(r.Context(), defaultInvoice, operatorID)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    // Reset transaction_id_settings
    defaultTrx := UpdateTransactionIDRequest{
        TrxPrefix:  strPtr("TRX"),
        TrxPattern: strPtr("DATE_DAILY"),
    }
    _, err = repository.UpdateTransactionIDSettings(r.Context(), defaultTrx, operatorID)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    json.NewEncoder(w).Encode(map[string]any{"success": true, "message": "reset berhasil"})
}

func strPtr(s string) *string { return &s }
func intPtr(i int) *int       { return &i }
```

---

## 5. Logic Penomoran Invoice

### 5.1 Format Nomor Invoice

Pola: `{PREFIX}-{SEGMENT}-{SEQUENCE}`

| `invoice_reset_rule` | Format | Contoh |
|---|---|---|
| `MONTHLY` | `INV-YYYYMM-000001` | `INV-202603-000001` |
| `YEARLY` | `INV-YYYY-000001` | `INV-2026-000001` |
| `NONE` | `INV-000001` | `INV-000001` |

### 5.2 Generator (Go)

```go
package invoice

import (
    "context"
    "fmt"
    "time"
)

// GenerateInvoiceNumber membuat nomor invoice baru berdasarkan settings.
// Sequence di-reset sesuai reset_rule.
func GenerateInvoiceNumber(ctx context.Context, settings model.InvoiceSettings) (string, error) {
    now := time.Now()
    prefix := settings.InvoicePrefix // e.g. "INV"

    var segment string
    var resetKey string // key unik untuk menentukan kapan sequence reset

    switch settings.InvoiceResetRule {
    case "MONTHLY":
        segment = fmt.Sprintf("%d%02d", now.Year(), now.Month())
        resetKey = segment
    case "YEARLY":
        segment = fmt.Sprintf("%d", now.Year())
        resetKey = segment
    case "NONE":
        segment = ""
        resetKey = "GLOBAL"
    }

    // Atomic increment: gunakan row-level lock di tabel invoice_sequences
    // CREATE TABLE invoice_sequences (
    //     reset_key TEXT PRIMARY KEY,
    //     current_seq BIGINT NOT NULL DEFAULT 0
    // );
    seq, err := repository.IncrementInvoiceSequence(ctx, resetKey)
    if err != nil {
        return "", fmt.Errorf("gagal increment sequence: %w", err)
    }

    seqStr := fmt.Sprintf("%06d", seq)

    if segment == "" {
        return fmt.Sprintf("%s-%s", prefix, seqStr), nil
    }
    return fmt.Sprintf("%s-%s-%s", prefix, segment, seqStr), nil
}
```

### 5.3 Sequence Repository (Atomic)

```go
func IncrementInvoiceSequence(ctx context.Context, resetKey string) (int64, error) {
    var seq int64
    err := db.QueryRowContext(ctx, `
        INSERT INTO invoice_sequences (reset_key, current_seq)
        VALUES ($1, 1)
        ON CONFLICT (reset_key)
        DO UPDATE SET current_seq = invoice_sequences.current_seq + 1
        RETURNING current_seq
    `, resetKey).Scan(&seq)
    return seq, err
}
```

---

## 6. Logic Format ID Transaksi (TRX)

### 6.1 Format

| `trx_pattern` | Format | Contoh |
|---|---|---|
| `DATE_DAILY` | `TRX-YYYYMMDD-XXXXXX` | `TRX-20260315-005520` |
| `DATE_MONTHLY` | `TRX-YYYYMM-XXXXXX` | `TRX-202603-005520` |
| `GLOBAL_SEQ` | `TRX-XXXXXX` | `TRX-005520` |

### 6.2 Generator (Go)

```go
func GenerateTransactionID(ctx context.Context, settings model.TransactionIDSettings) (string, error) {
    now := time.Now()
    prefix := settings.TrxPrefix

    var segment, resetKey string

    switch settings.TrxPattern {
    case "DATE_DAILY":
        segment = fmt.Sprintf("%d%02d%02d", now.Year(), now.Month(), now.Day())
        resetKey = "TRX_" + segment
    case "DATE_MONTHLY":
        segment = fmt.Sprintf("%d%02d", now.Year(), now.Month())
        resetKey = "TRX_" + segment
    case "GLOBAL_SEQ":
        segment = ""
        resetKey = "TRX_GLOBAL"
    }

    seq, err := repository.IncrementSequence(ctx, "transaction_sequences", resetKey)
    if err != nil {
        return "", err
    }

    seqStr := fmt.Sprintf("%06d", seq)
    if segment == "" {
        return fmt.Sprintf("%s-%s", prefix, seqStr), nil
    }
    return fmt.Sprintf("%s-%s-%s", prefix, segment, seqStr), nil
}
```

---

## 7. Logic Notifikasi Email Pengingat Expired

### 7.1 Trigger Values

| Value | Arti | Waktu Kirim |
|---|---|---|
| `D7` | H-7 | 7 hari sebelum `end_date` membership |
| `D3` | H-3 | 3 hari sebelum `end_date` |
| `D1` | H-1 | 1 hari sebelum |

### 7.2 Template Variables

| Variable | Contoh Isi | Sumber Data |
|---|---|---|
| `{nama_depan}` | `Maya` | `user_memberships.user_name` (split first name) |
| `{tanggal_berakhir}` | `20 September 2026` | `user_memberships.end_date` di-format |
| `{nama_plan}` | `Pro` | `user_memberships.plan_name` |
| `{sisa_hari}` | `7` | Selisih hari `end_date - today` |

### 7.3 Cron Job / Scheduler

```go
package scheduler

import (
    "context"
    "strings"
    "time"
)

// RunExpiryNotificationJob dijalankan via cron setiap hari pukul 08:00 WIB.
func RunExpiryNotificationJob(ctx context.Context) error {
    // 1. Ambil settings
    settings, err := repository.GetNotificationSettings(ctx)
    if err != nil || !settings.IsEnabled {
        return err // skip jika disabled
    }

    today := time.Now().Truncate(24 * time.Hour)

    // 2. Untuk setiap trigger, cari user yang match
    for _, trigger := range settings.Triggers {
        daysBefore := parseTriggerDays(trigger) // D7→7, D3→3, D1→1
        targetDate := today.AddDate(0, 0, daysBefore)

        // 3. Query user_memberships yang end_date = targetDate dan is_active = true
        users, err := repository.FindMembershipsExpiringOn(ctx, targetDate)
        if err != nil {
            log.Printf("error query expiring memberships: %v", err)
            continue
        }

        for _, um := range users {
            // 4. Cek apakah email sudah pernah dikirim untuk trigger+cycle ini
            //    (tabel notification_logs: user_id + trigger + cycle_id unique)
            alreadySent, _ := repository.IsNotificationSent(ctx, um.UserID, trigger, um.CurrentCycleID)
            if alreadySent {
                continue
            }

            // 5. Render template
            subject := renderTemplate(settings.EmailSubjectTemplate, um, daysBefore)
            body := renderTemplate(settings.EmailBodyTemplate, um, daysBefore)

            // 6. Ambil email footer dari invoice_settings
            invoiceSettings, _ := repository.GetInvoiceSettings(ctx)
            footer := "© 2026 Rextra Technology · Email dikirim otomatis"
            if invoiceSettings != nil && invoiceSettings.EmailFooterText != nil {
                footer = *invoiceSettings.EmailFooterText
            }

            // 7. Kirim email (via SMTP / SendGrid / etc.)
            err = emailService.Send(email.Message{
                To:      um.UserEmail,
                Subject: subject,
                HTML:    buildEmailHTML(um.UserName, body, footer),
            })
            if err != nil {
                log.Printf("gagal kirim email ke %s: %v", um.UserEmail, err)
                continue
            }

            // 8. Catat di notification_logs
            repository.LogNotification(ctx, um.UserID, trigger, um.CurrentCycleID)
        }
    }
    return nil
}

func parseTriggerDays(trigger string) int {
    switch trigger {
    case "D7": return 7
    case "D3": return 3
    case "D1": return 1
    default:   return 0
    }
}

func renderTemplate(template string, um model.UserMembership, sisaHari int) string {
    firstName := strings.SplitN(um.UserName, " ", 2)[0]
    r := strings.NewReplacer(
        "{nama_depan}",        firstName,
        "{tanggal_berakhir}",  formatTanggal(um.EndDate), // "20 September 2026"
        "{nama_plan}",         um.PlanName,
        "{sisa_hari}",         fmt.Sprintf("%d", sisaHari),
    )
    return r.Replace(template)
}
```

### 7.4 Email HTML Builder

```go
func buildEmailHTML(userName, bodyContent, footer string) string {
    firstName := strings.SplitN(userName, " ", 2)[0]

    return fmt.Sprintf(`
    <div style="max-width:480px;margin:0 auto;font-family:'Segoe UI',Tahoma,sans-serif">
        <!-- Top bar -->
        <div style="height:4px;background:#6366f1"></div>

        <!-- Header -->
        <div style="padding:12px 20px;border-bottom:1px solid #f0f0f0;display:flex;justify-content:space-between;align-items:center">
            <img src="https://your-cdn.com/logo-rextra.png" alt="Rextra" style="height:20px" />
            <span style="font-size:9px;color:#999;text-transform:uppercase;letter-spacing:1px">Membership</span>
        </div>

        <!-- Body -->
        <div style="padding:16px 20px">
            <p style="font-size:13px;color:#555;margin-bottom:8px">
                Halo, <strong style="color:#222">%s</strong>
            </p>
            <p style="font-size:13px;color:#555;line-height:1.6;white-space:pre-wrap;margin-bottom:16px">
                %s
            </p>
            <div style="text-align:center;margin:16px 0">
                <a href="https://app.rextra.id/membership/renew"
                   style="display:inline-block;background:#6366f1;color:#fff;padding:8px 24px;border-radius:4px;
                          font-size:13px;font-weight:600;text-decoration:none;letter-spacing:0.02em">
                    Perpanjang Membership
                </a>
            </div>
        </div>

        <!-- Footer -->
        <div style="border-top:1px solid #f0f0f0;padding:12px 20px;text-align:center">
            <p style="font-size:10px;color:#999;line-height:1.5">%s</p>
            <p style="font-size:9px;color:#ccc;margin-top:4px">
                Jika Anda tidak merasa mendaftar, abaikan email ini.
            </p>
        </div>
    </div>`, firstName, bodyContent, footer)
}
```

---

## 8. Logic Preview Dokumen (PDF Generation)

### 8.1 Struktur Dokumen Faktur/Invoice (A4)

```
┌─────────────────────────────────────────────┐
│  [Logo]  Nama Perusahaan          FAKTUR    │
│          Alamat                   #INV-...   │
│─────────────────────────────────────────────│
│  Ditagihkan kepada:     Tanggal: DD MMM YYYY│
│  [Nama User]            Dibayar: ... 02:30PM│
│  [Email]                Status: LUNAS       │
│─────────────────────────────────────────────│
│  No │ Item                    │ Qty │ Harga │
│   1 │ Membership Pro - 3 Bln  │  1  │ 450k  │
│─────────────────────────────────────────────│
│  [QR Code]              Subtotal: Rp 450.000│
│  Scan untuk                                 │
│  verifikasi             Diskon:   -Rp 0     │
│                         ─────────────────── │
│                         Total:    Rp 450.000│
│─────────────────────────────────────────────│
│  Informasi Tambahan:                        │
│  • Pembayaran tidak dapat dikembalikan      │
│  • Hubungi cs@rextra.id                     │
│                                             │
│           (spacer sampai bawah)             │
│                                             │
│═════════════════════════════════════════════│ ← garis solid #1e1e1e
│  [Footer disclaimer]      [Timestamp WIB]   │
└─────────────────────────────────────────────┘
```

### 8.2 PDF Generator (Go — menggunakan `go-wkhtmltopdf` atau `chromedp`)

```go
package pdf

import (
    "bytes"
    "fmt"
    "html/template"
    "time"
)

type InvoiceData struct {
    Settings       model.InvoiceSettings
    InvoiceNumber  string
    TransactionID  string

    // Billing
    UserName       string
    UserEmail      string
    PlanName       string
    DurationLabel  string // "3 Bulan"

    // Dates
    InvoiceDate    time.Time
    PaidAt         *time.Time
    DueDate        time.Time
    Status         string // LUNAS, BELUM DIBAYAR, etc.

    // Items
    Items          []InvoiceItem

    // Financials
    Subtotal       int64
    Discount       int64
    Total          int64
    PromoCode      *string

    // QR
    VerificationURL string
}

type InvoiceItem struct {
    No       int
    Name     string
    Qty      int
    Price    int64
}

func GenerateInvoicePDF(data InvoiceData) ([]byte, error) {
    // 1. Parse HTML template
    tmpl, err := template.ParseFiles("templates/invoice.html")
    if err != nil {
        return nil, err
    }

    // 2. Format data untuk template
    viewData := map[string]any{
        "CompanyName":    data.Settings.CompanyName,
        "CompanyAddress": data.Settings.CompanyAddress,
        "InvoiceTitle":   derefOr(data.Settings.InvoiceTitle, "FAKTUR"),
        "InvoiceNumber":  data.InvoiceNumber,
        "UserName":       data.UserName,
        "UserEmail":      data.UserEmail,
        "InvoiceDate":    formatTanggalIndo(data.InvoiceDate),
        "PaidAt":         formatTanggalWaktu(data.PaidAt),  // "15 Mar 2026, 02:30 PM"
        "DueDate":        formatTanggalIndo(data.DueDate),
        "Status":         data.Status,
        "Items":          data.Items,
        "Subtotal":       formatRupiah(data.Subtotal),
        "Discount":       formatRupiah(data.Discount),
        "Total":          formatRupiah(data.Total),
        "PromoCode":      data.PromoCode,
        "QRCodeURL":      fmt.Sprintf("https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=%s", data.VerificationURL),
        "Notes":          data.Settings.Notes,
        "TermsContent":   data.Settings.TermsContent,
        "FooterText":     data.Settings.FooterText,
        "PrintTimestamp":  formatTimestampWIB(time.Now()),
    }

    var buf bytes.Buffer
    if err := tmpl.Execute(&buf, viewData); err != nil {
        return nil, err
    }

    // 3. Convert HTML → PDF menggunakan wkhtmltopdf atau chromedp
    pdfBytes, err := htmlToPDF(buf.Bytes(), PDFOptions{
        PageSize:    "A4",
        MarginTop:   "2.54cm",
        MarginBottom:"2.54cm",
        MarginLeft:  "2.54cm",
        MarginRight: "2.54cm",
    })
    return pdfBytes, err
}

// Helper formatting
func formatTanggalIndo(t time.Time) string {
    months := []string{"", "Januari", "Februari", "Maret", "April", "Mei", "Juni",
        "Juli", "Agustus", "September", "Oktober", "November", "Desember"}
    return fmt.Sprintf("%d %s %d", t.Day(), months[t.Month()], t.Year())
}

func formatTanggalWaktu(t *time.Time) string {
    if t == nil { return "-" }
    loc, _ := time.LoadLocation("Asia/Jakarta")
    wib := t.In(loc)
    return fmt.Sprintf("%s, %s",
        formatTanggalIndo(wib),
        wib.Format("03:04 PM"),
    )
}

func formatTimestampWIB(t time.Time) string {
    loc, _ := time.LoadLocation("Asia/Jakarta")
    wib := t.In(loc)
    months := []string{"", "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
        "Jul", "Agu", "Sep", "Okt", "Nov", "Des"}
    return fmt.Sprintf("%02d %s %d, %02d.%02d WIB",
        wib.Day(), months[wib.Month()], wib.Year(), wib.Hour(), wib.Minute())
}

func formatRupiah(amount int64) string {
    // Format: Rp 450.000
    s := fmt.Sprintf("%d", amount)
    // Tambahkan separator ribuan
    var result []byte
    for i, c := range s {
        if i > 0 && (len(s)-i)%3 == 0 {
            result = append(result, '.')
        }
        result = append(result, byte(c))
    }
    return "Rp " + string(result)
}
```

---

## 9. Spesifikasi Dokumen Preview

### 9.1 Aturan Layout

| Aspek | Spesifikasi |
|---|---|
| Ukuran | A4 (210mm × 297mm) |
| Margin | 2.54cm semua sisi |
| Font | Segoe UI / Tahoma, sans-serif |
| Font size detail teknis | 9px |
| Garis pemisah header/section | `#e0e0e0` solid 1px |
| Garis pemisah footer | `#1e1e1e` solid 1px (lebih gelap) |
| Label Subtotal & Diskon | **Bold** |
| Format tanggal Dibayar | `DD MMM YYYY, HH:MM AM/PM` |
| QR Code | Kanan bawah, ukuran 80×80px, label "Scan untuk verifikasi" (tanpa URL teks) |
| Footer kiri | Disclaimer sistem |
| Footer kanan | Timestamp cetak (WIB) |

### 9.2 Logic Jatuh Tempo

```go
func CalculateDueDate(invoiceDate time.Time, defaultDueDays int) time.Time {
    if defaultDueDays <= 0 {
        return invoiceDate // Jatuh tempo = tanggal invoice
    }
    return invoiceDate.AddDate(0, 0, defaultDueDays)
}
```

---

## 10. Tabel Pendukung Tambahan

### 10.1 `invoice_sequences` (untuk atomic counter)

```sql
CREATE TABLE invoice_sequences (
    reset_key   TEXT PRIMARY KEY,
    current_seq BIGINT NOT NULL DEFAULT 0
);
```

### 10.2 `notification_logs` (untuk dedup pengiriman email)

```sql
CREATE TABLE notification_logs (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID NOT NULL,
    trigger    TEXT NOT NULL,        -- D7, D3, D1
    cycle_id   UUID NOT NULL,        -- referensi ke subscription_cycles
    sent_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (user_id, trigger, cycle_id)
);
```

---

## 11. Router Setup

```go
package main

import (
    "net/http"
    "github.com/go-chi/chi/v5"
)

func SetupRoutes(r chi.Router) {
    r.Route("/api/v1/settings", func(r chi.Router) {
        r.Use(authMiddleware) // require authenticated admin

        // Notifikasi
        r.Get("/notification", handler.GetNotificationSettings)
        r.Patch("/notification", handler.UpdateNotificationSettings)

        // Invoice / Dokumen
        r.Get("/invoice", handler.GetInvoiceSettings)
        r.Patch("/invoice", handler.UpdateInvoiceSettings)

        // Transaction ID
        r.Get("/transaction-id", handler.GetTransactionIDSettings)
        r.Patch("/transaction-id", handler.UpdateTransactionIDSettings)

        // Reset
        r.Post("/document/reset", handler.ResetDocumentDefaults)
    })
}
```

---

## 12. Ringkasan Alur

```
┌──────────────┐     PATCH /settings/*     ┌─────────────┐
│  Frontend    │ ────────────────────────▶  │  Go Handler  │
│  (React)     │                            │  - Validasi  │
│              │ ◀──── 200 JSON ────────── │  - Update DB │
└──────────────┘                            └─────────────┘

┌──────────────┐     Cron 08:00 WIB        ┌─────────────┐
│  Scheduler   │ ────────────────────────▶  │  Query users │
│  (cron job)  │                            │  with expiry │
│              │                            │  = today + N │
│              │                            │  ↓           │
│              │                            │  Render tmpl │
│              │                            │  ↓           │
│              │                            │  Send email  │
│              │                            │  ↓           │
│              │                            │  Log sent    │
└──────────────┘                            └─────────────┘

┌──────────────┐     GET /invoice/pdf/:id   ┌─────────────┐
│  User clicks │ ────────────────────────▶  │  Go Handler  │
│  "Download"  │                            │  ↓           │
│              │                            │  Fetch data  │
│              │ ◀── PDF binary ──────────  │  ↓           │
│              │                            │  HTML→PDF    │
└──────────────┘                            └─────────────┘
```
