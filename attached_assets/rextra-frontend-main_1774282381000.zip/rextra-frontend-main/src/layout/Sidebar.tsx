'use client'

import React, { useState, useEffect } from 'react'
import { usePathname } from 'next/navigation'
import {
  User,
  BarChart2,
  GraduationCap,
  Users,
  Heart,
  Building2,
  FileText,
  Trophy,
  DollarSign,
  ChevronDown,
  ChevronLeft,
  Menu,
  X,
} from 'lucide-react'
import Link from 'next/link'
import NextImage from '@/components/next-image'
import { cn } from '@/lib/utils'

const menuData = [
  {
    category: 'Mahasiswa',
    items: [
      {
        label: 'Akun Mahasiswa',
        icon: User,
        href: '/dashboard/mahasiswa/akun',
      },
      {
        label: 'Persona Rextra',
        icon: BarChart2,
        href: '/dashboard/mahasiswa/persona',
      },
      {
        label: 'Pendidikan',
        icon: GraduationCap,
        href: '/dashboard/mahasiswa/pendidikan',
      },
      {
        label: 'Rextra Club',
        icon: Users,
        href: '#',
        children: [
          { label: 'Member List', href: '/dashboard/rextra-club/members' },
        ],
      },
      {
        label: 'Kenali Diri',
        icon: Heart,
        href: '#',
        children: [
          { label: 'Master Data', href: '/expert/kenali-diri/master-data' },
          { label: 'Hasil Tes', href: '/expert/kenali-diri/hasil-tes' },
          { label: 'Umpan Balik', href: '/expert/kenali-diri/umpan-balik' },
        ],
      },
    ],
  },
  {
    category: 'Perusahaan',
    items: [
      {
        label: 'Profil Perusahaan',
        icon: Building2,
        href: '/dashboard/perusahaan/profil',
      },
      {
        label: 'Lowongan Pekerjaan',
        icon: FileText,
        href: '/dashboard/perusahaan/loker',
      },
    ],
  },
  {
    category: 'Performa',
    items: [
      {
        label: 'Capaian Pengguna',
        icon: Trophy,
        href: '/dashboard/performa/pengguna',
      },
      {
        label: 'Capaian Keuangan',
        icon: DollarSign,
        href: '/dashboard/performa/keuangan',
      },
      {
        label: 'Visualisasi Performa',
        icon: BarChart2,
        href: '/dashboard/performa/visualisasi',
      },
    ],
  },
]

// ─── Komponen isi sidebar (dipakai di desktop & mobile) ───────────────────────
function SidebarContent({
  isOpen,
  onClose,
  isMobile = false,
}: {
  isOpen: boolean
  onClose: () => void
  isMobile?: boolean
}) {
  const [expandedMenus, setExpandedMenus] = useState<string[]>([])
  const pathname = usePathname()

  const toggleMenu = (label: string) => {
    setExpandedMenus((prev) =>
      prev.includes(label)
        ? prev.filter((item) => item !== label)
        : [...prev, label],
    )
  }

  useEffect(() => {
    menuData.forEach((section) => {
      section.items.forEach((item) => {
        if (item.children) {
          const isChildActive = item.children.some(
            (child) => child.href === pathname,
          )
          if (isChildActive) {
            setExpandedMenus((prev) =>
              prev.includes(item.label) ? prev : [...prev, item.label],
            )
          }
        }
      })
    })
  }, [pathname])

  return (
    <div className="flex flex-col h-full">
      {/* HEADER */}
      <div
        className={cn(
          'h-20 flex items-center mb-2 border-b border-[#B5B7B8] shrink-0',
          isOpen && !isMobile
            ? 'justify-between px-6'
            : isMobile
              ? 'justify-between px-6'
              : 'justify-center px-0',
        )}
      >
        <div className="flex items-center gap-3 overflow-hidden whitespace-nowrap min-w-0">
          {isOpen || isMobile ? (
            <NextImage
              src="/dashboard/logo-rextra.webp"
              alt="Rextra Full Logo"
              width={150}
              height={35}
              className="object-contain transition-opacity duration-300"
              priority
            />
          ) : (
            <NextImage
              src="/dashboard/logo-mini.svg"
              alt="Rextra Icon"
              width={37}
              height={44}
              className="object-contain transition-opacity duration-300"
              priority
            />
          )}
        </div>

        {/* Tombol tutup: di desktop ketika open, selalu di mobile */}
        {(isOpen || isMobile) && (
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 ml-2"
          >
            {isMobile ? <X size={24} /> : <ChevronLeft size={24} />}
          </button>
        )}
      </div>

      {/* MENU LIST */}
      <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pb-10">
        {menuData.map((section, idx) => (
          <div key={idx} className="mb-6">
            <div className="gap-1">
              {section.items.map((item) => {
                const hasChildren = item.children && item.children.length > 0
                const isMenuExpanded = expandedMenus.includes(item.label)
                const isSelfActive = pathname === item.href
                const isChildActive = item.children?.some(
                  (c) => c.href === pathname,
                )
                const isParentActive = isSelfActive || isChildActive

                return (
                  <div key={item.label}>
                    {hasChildren ? (
                      <button
                        onClick={() => toggleMenu(item.label)}
                        className={cn(
                          'flex items-center w-full p-3 rounded-2xl transition-all duration-200 group relative',
                          isOpen || isMobile
                            ? 'justify-between'
                            : 'justify-center flex-col gap-1',
                          isParentActive && (isOpen || isMobile)
                            ? 'bg-blue-50 text-blue-900 font-semibold'
                            : 'text-gray-600 hover:bg-gray-50',
                          isParentActive && !isOpen && !isMobile
                            ? 'bg-blue-50/50 text-blue-900'
                            : '',
                        )}
                      >
                        <div
                          className={cn(
                            'flex items-center gap-4',
                            !isOpen && !isMobile && 'flex-col gap-0',
                          )}
                        >
                          <item.icon
                            size={24}
                            className={cn(
                              isParentActive
                                ? 'text-blue-800'
                                : 'text-gray-500 group-hover:text-gray-700',
                            )}
                            strokeWidth={1.5}
                          />
                          <span
                            className={cn(
                              'whitespace-nowrap transition-all duration-200 font-medium font-Poppins text-[16px]',
                              isOpen || isMobile
                                ? 'opacity-100'
                                : 'opacity-0 w-0 h-0 hidden',
                            )}
                          >
                            {item.label}
                          </span>
                        </div>
                        {(isOpen || isMobile) && (
                          <ChevronDown
                            size={18}
                            className={cn(
                              'transition-transform duration-200 text-gray-400',
                              isMenuExpanded ? 'rotate-180' : '',
                            )}
                          />
                        )}
                      </button>
                    ) : (
                      <Link
                        href={item.href}
                        className={cn(
                          'flex items-center w-full p-3 rounded-2xl transition-all duration-200 group relative',
                          isOpen || isMobile
                            ? 'justify-start'
                            : 'justify-center flex-col gap-1',
                          isSelfActive
                            ? 'bg-blue-50 text-blue-900 font-semibold'
                            : 'text-gray-600 hover:bg-gray-50',
                        )}
                      >
                        <div
                          className={cn(
                            'flex items-center gap-4',
                            !isOpen && !isMobile && 'flex-col gap-0',
                          )}
                        >
                          <item.icon
                            size={24}
                            className={cn(
                              isSelfActive
                                ? 'text-blue-800'
                                : 'text-gray-500 group-hover:text-gray-700',
                            )}
                            strokeWidth={1.5}
                          />
                          <span
                            className={cn(
                              'whitespace-nowrap transition-all duration-200 font-medium font-Poppins text-[16px]',
                              isOpen || isMobile
                                ? 'opacity-100'
                                : 'opacity-0 w-0 h-0 hidden',
                            )}
                          >
                            {item.label}
                          </span>
                        </div>
                      </Link>
                    )}

                    {/* Sub Menu */}
                    {hasChildren && (isOpen || isMobile) && (
                      <div
                        className={cn(
                          'grid transition-all duration-300 ease-in-out overflow-hidden',
                          isMenuExpanded
                            ? 'grid-rows-[1fr] opacity-100 mt-2'
                            : 'grid-rows-[0fr] opacity-0 mt-0',
                        )}
                      >
                        <div className="min-h-0 relative">
                          <div className="absolute left-[35.5px] top-0 bottom-4 w-px bg-gray-200 z-0" />
                          {item.children?.map((subItem, subIdx) => {
                            const isSubActive = pathname === subItem.href
                            return (
                              <Link
                                key={subIdx}
                                href={subItem.href}
                                className="relative flex items-center py-2 pl-16 text-sm hover:text-blue-600 group/sub w-full"
                              >
                                <div
                                  className={cn(
                                    'absolute left-9 top-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full border-2 transition-all z-10',
                                    isSubActive
                                      ? 'border-blue-600 bg-blue-600'
                                      : 'border-gray-300 bg-white group-hover/sub:border-blue-400',
                                  )}
                                />
                                <span
                                  className={cn(
                                    isSubActive
                                      ? 'font-medium text-blue-900'
                                      : 'text-gray-500',
                                  )}
                                >
                                  {subItem.label}
                                </span>
                              </Link>
                            )
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Komponen utama Sidebar ───────────────────────────────────────────────────
export default function Sidebar() {
  const [isOpen, setIsOpen] = useState(true)
  const [mobileOpen, setMobileOpen] = useState(false)

  const toggleSidebar = () => setIsOpen((v) => !v)
  const openMobile = () => setMobileOpen(true)
  const closeMobile = () => setMobileOpen(false)

  // Tutup mobile sidebar saat rute berubah
  const pathname = usePathname()
  useEffect(() => {
    setMobileOpen(false)
  }, [pathname])

  // Prevent body scroll saat mobile sidebar terbuka
  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => {
      document.body.style.overflow = ''
    }
  }, [mobileOpen])

  return (
    <>
      {/* ── DESKTOP SIDEBAR (md ke atas) ─────────────────────────────────── */}
      <aside
        className={cn(
          'hidden md:flex flex-col',
          'shadow-[3px_9px_7px_7px_rgba(77,77,86,0.04)]',
          'bg-white border-r border-[#B5B7B8] transition-all duration-300 ease-in-out',
          isOpen ? 'w-[318px]' : 'w-[139px]',
        )}
      >
        <SidebarContent
          isOpen={isOpen}
          onClose={toggleSidebar}
          isMobile={false}
        />

        {/* Klik seluruh area saat collapsed untuk expand */}
        {!isOpen && (
          <button
            onClick={toggleSidebar}
            className="absolute top-0 bottom-0 left-0 right-0 z-10 w-full h-full cursor-pointer bg-transparent"
            style={{ pointerEvents: 'none' }}
          />
        )}
      </aside>

      {/* ── MOBILE: Hamburger icon (di bawah md) ──────────────────────────── */}
      <button
        onClick={openMobile}
        className={cn(
          'md:hidden fixed top-4 left-4 z-40',
          'bg-white border border-[#B5B7B8] rounded-xl p-2',
          'shadow-md text-gray-600 hover:text-gray-900 transition-colors',
        )}
        aria-label="Buka Menu"
      >
        <Menu size={22} />
      </button>

      {/* ── MOBILE: Overlay backdrop ─────────────────────────────────────── */}
      {mobileOpen && (
        <div
          className="md:hidden fixed inset-0 z-40 bg-black/40 backdrop-blur-sm"
          onClick={closeMobile}
        />
      )}

      {/* ── MOBILE: Sidebar drawer (slide in dari kiri) ───────────────────── */}
      <aside
        className={cn(
          'md:hidden fixed top-0 left-0 h-full z-50',
          'bg-white shadow-2xl',
          'w-[300px]',
          'transition-transform duration-300 ease-in-out',
          mobileOpen ? 'translate-x-0' : '-translate-x-full',
        )}
      >
        <SidebarContent isOpen={true} onClose={closeMobile} isMobile={true} />
      </aside>
    </>
  )
}
